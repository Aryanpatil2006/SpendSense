# Project Statement

## Problem Statement

College students manage small, frequent, cash-and-UPI-heavy expenses — canteen meals, bus fares, photocopies, hostel bills — that individually feel trivial but collectively consume the bulk of a monthly allowance. Most students therefore reach the end of the month unable to explain where their money went.

Existing expense-tracking applications fail this group for three reasons:

1. **Logging friction.** Conventional trackers require a multi-field form for every transaction. A student buying a ₹40 bus ticket will not open an app and fill five fields, so logging is abandoned within days and the dataset is never complete enough to be useful.
2. **Generic categories.** Mainstream apps categorise around adult spending — mortgages, insurance, fuel, groceries. They have no notion of academic supplies, hostel bills, or campus food, so student spending collapses into an uninformative "Other" bucket.
3. **Data without insight.** Even when data is captured, most tools stop at a pie chart. They report *what* was spent but never tell the student what their spending pattern reveals about their habits, which transactions were genuinely abnormal, or how much they can safely spend tomorrow.

**SpendWise** addresses all three. It reduces logging to a single natural-language sentence, classifies spending into eight categories designed around student life, and converts the resulting history into interpretable behavioural insight — a spending personality profile, statistically grounded anomaly alerts, a daily-velocity heatmap, and a budget engine that computes a safe daily allowance for the days remaining in the month.

## Scope of the Project

**In scope**

- Natural-language expense entry with regex tokenisation and keyword-based category inference.
- A structured manual-entry alternative with validation for amount, date, payment method, and notes.
- Automatic classification into eight student-tailored categories.
- A heatmap calendar of daily spending on a five-tier intensity scale, with an interactive per-day transaction inspector.
- Derived behavioural statistics: peak and most-frugal days, active logging streaks, and weekend-versus-weekday splits.
- A rule-based spending personality engine with transparent rationale and actionable advice.
- A statistical anomaly detector using per-category baseline averages with three-level severity grading.
- Monthly budget management with utilisation percentages, colour-coded status badges, recommended daily allowance, editable limits, and reset-to-defaults.
- Visual analytics: interactive SVG donut chart, daily velocity bar chart, and payment-method breakdown.
- Report generation, printable statements, and CSV import/export.
- Local persistence so data survives browser restarts.

**Out of scope**

- Multi-user accounts, authentication, and cloud synchronisation.
- Bank, UPI, or SMS integration for automatic transaction import.
- Native mobile applications.
- Machine-learning models — classification and personality assignment are deliberately rule-based so that every decision remains explainable to the student.
- Income tracking, investments, and long-term financial planning.

## Target Users

**Primary — college students living on a fixed monthly allowance.** Typically hostel residents or day scholars making many small daily transactions, predominantly via UPI and cash, who want to understand their spending without the overhead of disciplined bookkeeping.

**Secondary — students preparing a monthly budget request.** Students who need concrete, category-wise evidence of their actual expenditure when discussing their allowance with parents or guardians.

**Tertiary — first-time budgeters generally.** Anyone new to personal finance who benefits more from interpreted, plain-language insight than from raw transaction tables.

## High-Level Features

The system is organised around three major functional modules, supported by three analytical and reporting capabilities.

**Module 1 — Expense Capture & Classification**
Dual-mode entry (natural language and structured form), regex-based amount extraction, keyword-map category inference across eight categories, and full input validation.

**Module 2 — Temporal Visualisation & Behavioural Analytics**
Five-tier heatmap calendar of daily spending velocity, interactive day inspector, streak and peak/frugal-day detection, weekend-versus-weekday analysis, and the Spending Personality Engine with explained reasoning.

**Module 3 — Budget Control & Anomaly Detection**
Per-category monthly limits with utilisation tracking and four-state status badges, recommended daily spend allowance for remaining days, and statistical anomaly detection reporting exact multipliers and surplus over category baselines.

**Supporting capabilities**
Interactive SVG donut and bar charts, payment-method distribution across UPI/Cash/Debit Card/Credit Card/Net Banking, and formal report generation with printable statements and CSV import/export.
