import { Expense, Budget, CategoryType, PaymentMethod } from '../types';
import { INITIAL_SAMPLE_EXPENSES, DEFAULT_BUDGETS } from '../data/sampleData';
import { ALL_CATEGORIES } from '../data/categories';

const EXPENSES_STORAGE_KEY = 'spendwise_expenses_v1';
const BUDGETS_STORAGE_KEY = 'spendwise_budgets_v1';

export function loadExpenses(): Expense[] {
  try {
    const raw = localStorage.getItem(EXPENSES_STORAGE_KEY);
    if (!raw) {
      saveExpenses(INITIAL_SAMPLE_EXPENSES);
      return INITIAL_SAMPLE_EXPENSES;
    }
    const parsed = JSON.parse(raw);
    if (Array.isArray(parsed) && parsed.length > 0) {
      return parsed;
    }
    return INITIAL_SAMPLE_EXPENSES;
  } catch (err) {
    console.warn('Failed to load expenses from localStorage, using sample data:', err);
    return INITIAL_SAMPLE_EXPENSES;
  }
}

export function saveExpenses(expenses: Expense[]): void {
  try {
    localStorage.setItem(EXPENSES_STORAGE_KEY, JSON.stringify(expenses));
  } catch (err) {
    console.error('Failed to save expenses to localStorage:', err);
  }
}

export function loadBudgets(): Budget[] {
  try {
    const raw = localStorage.getItem(BUDGETS_STORAGE_KEY);
    if (!raw) {
      saveBudgets(DEFAULT_BUDGETS);
      return DEFAULT_BUDGETS;
    }
    const parsed = JSON.parse(raw);
    if (Array.isArray(parsed) && parsed.length > 0) {
      return parsed;
    }
    return DEFAULT_BUDGETS;
  } catch (err) {
    console.warn('Failed to load budgets from localStorage, using defaults:', err);
    return DEFAULT_BUDGETS;
  }
}

export function saveBudgets(budgets: Budget[]): void {
  try {
    localStorage.setItem(BUDGETS_STORAGE_KEY, JSON.stringify(budgets));
  } catch (err) {
    console.error('Failed to save budgets to localStorage:', err);
  }
}

export function exportExpensesToCSV(expenses: Expense[]): string {
  const headers = ['ID', 'Date', 'Amount (INR)', 'Category', 'Description', 'Payment Method', 'Note'];
  const rows = expenses.map((e) => [
    `"${e.id}"`,
    `"${e.date}"`,
    e.amount,
    `"${e.category}"`,
    `"${(e.description || '').replace(/"/g, '""')}"`,
    `"${e.paymentMethod}"`,
    `"${(e.note || '').replace(/"/g, '""')}"`,
  ]);

  return [headers.join(','), ...rows.map((r) => r.join(','))].join('\n');
}

export function downloadCSV(content: string, filename: string = 'spendwise_expenses.csv'): void {
  const blob = new Blob([content], { type: 'text/csv;charset=utf-8;' });
  const url = URL.createObjectURL(blob);
  const link = document.createElement('a');
  link.setAttribute('href', url);
  link.setAttribute('download', filename);
  link.style.visibility = 'hidden';
  document.body.appendChild(link);
  link.click();
  document.body.removeChild(link);
  URL.revokeObjectURL(url);
}

export function parseCSVToExpenses(csvText: string): { expenses: Expense[]; errors: string[] } {
  const lines = csvText.split(/\r?\n/).filter((l) => l.trim().length > 0);
  if (lines.length < 2) {
    return { expenses: [], errors: ['CSV file appears empty or missing header.'] };
  }

  const results: Expense[] = [];
  const errors: string[] = [];

  // Assume row 0 is header: ID, Date, Amount, Category, Description, Payment Method, Note
  for (let i = 1; i < lines.length; i++) {
    const line = lines[i].trim();
    if (!line) continue;

    // Simple CSV parser handling quotes
    const regex = /(?:^|,)(?:"([^"]*(?:""[^"]*)*)"|([^",]*))/g;
    const values: string[] = [];
    let match;
    while ((match = regex.exec(line)) !== null) {
      // match[1] is quoted, match[2] is unquoted
      let val = match[1] !== undefined ? match[1].replace(/""/g, '"') : match[2];
      values.push(val.trim());
    }

    if (values.length < 4) {
      errors.push(`Line ${i + 1}: Insufficient columns`);
      continue;
    }

    const dateVal = values[1] || values[0];
    const amountVal = parseFloat(values[2] || values[1]);
    const catVal = values[3] as CategoryType;
    const descVal = values[4] || 'Imported Expense';
    const payMethodVal = (values[5] || 'UPI') as PaymentMethod;
    const noteVal = values[6] || '';

    if (isNaN(amountVal) || amountVal <= 0) {
      errors.push(`Line ${i + 1}: Invalid amount "${values[2]}"`);
      continue;
    }

    const validCat = ALL_CATEGORIES.includes(catVal) ? catVal : 'Other';

    results.push({
      id: `imp-${Date.now()}-${i}`,
      date: dateVal.match(/^\d{4}-\d{2}-\d{2}$/) ? dateVal : '2026-09-07',
      amount: amountVal,
      category: validCat,
      description: descVal,
      paymentMethod: payMethodVal,
      note: noteVal,
      createdAt: Date.now() - i * 1000,
    });
  }

  return { expenses: results, errors };
}
