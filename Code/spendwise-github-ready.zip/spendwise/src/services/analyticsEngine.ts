import {
  Expense,
  Budget,
  CategoryType,
  CategoryBudgetProgress,
  SpendingPersonality,
  SmartInsight,
} from '../types';
import { ALL_CATEGORIES } from '../data/categories';

export interface DailySpending {
  date: string;
  dayOfMonth: number;
  dayName: string;
  amount: number;
  count: number;
  isWeekend: boolean;
  intensity: 0 | 1 | 2 | 3 | 4;
}

export interface SpendingSummary {
  totalSpent: number;
  todaySpent: number;
  thisMonthSpent: number;
  lastMonthSpent: number;
  monthOverMonthGrowth: number;
  highestCategory: CategoryType | 'None';
  highestCategoryAmount: number;
  highestCategoryPercentage: number;
  transactionCount: number;
  dailyAverageThisMonth: number;
  activeDaysCount: number;
}

export interface WeekendVsWeekday {
  weekendTotal: number;
  weekdayTotal: number;
  weekendAvgPerDay: number;
  weekdayAvgPerDay: number;
  weekendPercentage: number;
  weekdayPercentage: number;
}

export function computeSummary(expenses: Expense[], referenceDate: string = '2026-09-07'): SpendingSummary {
  const [currentYear, currentMonthStr] = referenceDate.split('-');
  const currentYearMonth = `${currentYear}-${currentMonthStr}`;

  // Previous month calculation
  const curMonthNum = parseInt(currentMonthStr, 10);
  const prevMonthNum = curMonthNum === 1 ? 12 : curMonthNum - 1;
  const prevYear = curMonthNum === 1 ? parseInt(currentYear, 10) - 1 : currentYear;
  const prevMonthStr = String(prevMonthNum).padStart(2, '0');
  const prevYearMonth = `${prevYear}-${prevMonthStr}`;

  let totalSpent = 0;
  let todaySpent = 0;
  let thisMonthSpent = 0;
  let lastMonthSpent = 0;

  const categoryTotals: Record<CategoryType, number> = {
    Food: 0,
    Transport: 0,
    Academic: 0,
    Entertainment: 0,
    Shopping: 0,
    Health: 0,
    Bills: 0,
    Other: 0,
  };

  const daysWithSpend = new Set<string>();

  for (const exp of expenses) {
    totalSpent += exp.amount;

    if (exp.date === referenceDate) {
      todaySpent += exp.amount;
    }

    if (exp.date.startsWith(currentYearMonth)) {
      thisMonthSpent += exp.amount;
      categoryTotals[exp.category] = (categoryTotals[exp.category] || 0) + exp.amount;
      daysWithSpend.add(exp.date);
    } else if (exp.date.startsWith(prevYearMonth)) {
      lastMonthSpent += exp.amount;
    }
  }

  // Find highest category this month
  let highestCategory: CategoryType | 'None' = 'None';
  let highestCategoryAmount = 0;
  for (const cat of ALL_CATEGORIES) {
    if (categoryTotals[cat] > highestCategoryAmount) {
      highestCategoryAmount = categoryTotals[cat];
      highestCategory = cat;
    }
  }

  const highestCategoryPercentage =
    thisMonthSpent > 0 ? Math.round((highestCategoryAmount / thisMonthSpent) * 100) : 0;

  // Day of month for daily average
  const dayOfMonth = parseInt(referenceDate.split('-')[2], 10) || 1;
  const dailyAverageThisMonth = Math.round(thisMonthSpent / Math.max(1, dayOfMonth));

  // Month over month growth
  let monthOverMonthGrowth = 0;
  if (lastMonthSpent > 0) {
    monthOverMonthGrowth = Math.round(((thisMonthSpent - lastMonthSpent) / lastMonthSpent) * 100);
  }

  return {
    totalSpent,
    todaySpent,
    thisMonthSpent,
    lastMonthSpent,
    monthOverMonthGrowth,
    highestCategory,
    highestCategoryAmount,
    highestCategoryPercentage,
    transactionCount: expenses.length,
    dailyAverageThisMonth,
    activeDaysCount: daysWithSpend.size,
  };
}

export function computeCategoryDistribution(
  expenses: Expense[],
  monthFilter?: string
): { category: CategoryType; amount: number; percentage: number; count: number }[] {
  const filtered = monthFilter
    ? expenses.filter((e) => e.date.startsWith(monthFilter))
    : expenses;

  const totals: Record<CategoryType, { amount: number; count: number }> = {
    Food: { amount: 0, count: 0 },
    Transport: { amount: 0, count: 0 },
    Academic: { amount: 0, count: 0 },
    Entertainment: { amount: 0, count: 0 },
    Shopping: { amount: 0, count: 0 },
    Health: { amount: 0, count: 0 },
    Bills: { amount: 0, count: 0 },
    Other: { amount: 0, count: 0 },
  };

  let totalSum = 0;
  for (const exp of filtered) {
    totals[exp.category].amount += exp.amount;
    totals[exp.category].count += 1;
    totalSum += exp.amount;
  }

  return ALL_CATEGORIES.map((cat) => {
    const amount = totals[cat].amount;
    const percentage = totalSum > 0 ? Math.round((amount / totalSum) * 100) : 0;
    return {
      category: cat,
      amount,
      percentage,
      count: totals[cat].count,
    };
  }).sort((a, b) => b.amount - a.amount);
}

export function computeSpendingPersonality(
  expenses: Expense[],
  budgets: Budget[],
  referenceMonth: string = '2026-09'
): SpendingPersonality {
  const monthExpenses = expenses.filter((e) => e.date.startsWith(referenceMonth));
  const activeExpenses = monthExpenses.length > 0 ? monthExpenses : expenses;

  const totalSpent = activeExpenses.reduce((sum, e) => sum + e.amount, 0);
  const totalBudget = budgets.reduce((sum, b) => sum + b.monthlyLimit, 0);

  const categoryTotals: Record<CategoryType, number> = {
    Food: 0,
    Transport: 0,
    Academic: 0,
    Entertainment: 0,
    Shopping: 0,
    Health: 0,
    Bills: 0,
    Other: 0,
  };

  for (const exp of activeExpenses) {
    categoryTotals[exp.category] = (categoryTotals[exp.category] || 0) + exp.amount;
  }

  const foodPct = totalSpent > 0 ? (categoryTotals.Food / totalSpent) * 100 : 0;
  const transportPct = totalSpent > 0 ? (categoryTotals.Transport / totalSpent) * 100 : 0;
  const academicPct = totalSpent > 0 ? (categoryTotals.Academic / totalSpent) * 100 : 0;
  const entPct = totalSpent > 0 ? (categoryTotals.Entertainment / totalSpent) * 100 : 0;
  const shoppingPct = totalSpent > 0 ? (categoryTotals.Shopping / totalSpent) * 100 : 0;

  // Determine personality
  if (foodPct >= 35) {
    return {
      type: 'Foodie',
      title: 'The Campus Foodie 🍔',
      tagline: 'Canteen visits, cafe runs, and food delivery fuel your days.',
      description: `Food accounts for ${foodPct.toFixed(1)}% of your recorded spending (₹${categoryTotals.Food.toLocaleString()}). You enjoy sharing meals with campus friends and trying different snacks.`,
      badgeColor: 'bg-orange-100 text-orange-800 border-orange-200',
      accentBg: 'from-orange-50 to-amber-50',
      keyMetric: `${foodPct.toFixed(0)}% on Food`,
      studentAdvice:
        'Tip: Opt for student mess meals or bulk canteen tokens twice a week to trim snacking costs while staying fueled.',
      stats: {
        dominantCategory: 'Food',
        dominantPercentage: Math.round(foodPct),
        transactionCount: activeExpenses.length,
        totalSpent,
      },
    };
  }

  if (academicPct >= 28) {
    return {
      type: 'Academic Focused',
      title: 'The Academic Striver 📚',
      tagline: 'Deeply invested in learning tools, textbooks, xerox, and lab kits.',
      description: `Academic supplies, reference texts, and materials represent ${academicPct.toFixed(1)}% of your expenses (₹${categoryTotals.Academic.toLocaleString()}). Your spending directly supports coursework success.`,
      badgeColor: 'bg-purple-100 text-purple-800 border-purple-200',
      accentBg: 'from-purple-50 to-indigo-50',
      keyMetric: `${academicPct.toFixed(0)}% on Academics`,
      studentAdvice:
        'Tip: Check if senior batches have lab component kits or shared PDF reference banks to reduce one-time semester outlays.',
      stats: {
        dominantCategory: 'Academic',
        dominantPercentage: Math.round(academicPct),
        transactionCount: activeExpenses.length,
        totalSpent,
      },
    };
  }

  if (transportPct >= 25) {
    return {
      type: 'Transport Heavy',
      title: 'The Daily Commuter 🚌',
      tagline: 'Metro tokens, bus routes, and auto fares dominate your journal.',
      description: `Transit and travel consume ${transportPct.toFixed(1)}% of your expenses (₹${categoryTotals.Transport.toLocaleString()}). You are constantly in motion between hostel, college, and city.`,
      badgeColor: 'bg-sky-100 text-sky-800 border-sky-200',
      accentBg: 'from-sky-50 to-blue-50',
      keyMetric: `${transportPct.toFixed(0)}% on Transport`,
      studentAdvice:
        'Tip: Look into monthly institutional student transit passes or coordinate shared carpool/auto rides with batchmates.',
      stats: {
        dominantCategory: 'Transport',
        dominantPercentage: Math.round(transportPct),
        transactionCount: activeExpenses.length,
        totalSpent,
      },
    };
  }

  if (entPct >= 25) {
    return {
      type: 'Entertainment Focused',
      title: 'The Social Butterfly 🍿',
      tagline: 'Cinema weekends, gaming setups, and social outings take center stage.',
      description: `Entertainment and subscriptions account for ${entPct.toFixed(1)}% of your expenses (₹${categoryTotals.Entertainment.toLocaleString()}). You value relaxation and memorable times.`,
      badgeColor: 'bg-pink-100 text-pink-800 border-pink-200',
      accentBg: 'from-pink-50 to-rose-50',
      keyMetric: `${entPct.toFixed(0)}% on Entertainment`,
      studentAdvice:
        'Tip: Make sure you are using student pricing for streaming and take advantage of campus movie nights or college fest passes.',
      stats: {
        dominantCategory: 'Entertainment',
        dominantPercentage: Math.round(entPct),
        transactionCount: activeExpenses.length,
        totalSpent,
      },
    };
  }

  // Check Saver (spending under 50% of budget)
  if (totalBudget > 0 && totalSpent / totalBudget < 0.55) {
    const savingsEst = Math.round(((totalBudget - totalSpent) / totalBudget) * 100);
    return {
      type: 'Saver',
      title: 'The Disciplined Saver 💰',
      tagline: 'Prudent budgeting and watchful control over non-essential expenses.',
      description: `You have spent only ${((totalSpent / totalBudget) * 100).toFixed(0)}% of your planned budget, keeping ₹${(totalBudget - totalSpent).toLocaleString()} safely in reserve.`,
      badgeColor: 'bg-emerald-100 text-emerald-800 border-emerald-200',
      accentBg: 'from-emerald-50 to-teal-50',
      keyMetric: `${savingsEst}% Budget Retained`,
      studentAdvice:
        'Tip: Great discipline! Consider setting aside part of this surplus into an emergency college fund or high-yield savings.',
      stats: {
        savingsRateEstimate: savingsEst,
        dominantPercentage: Math.round(foodPct),
        transactionCount: activeExpenses.length,
        totalSpent,
      },
    };
  }

  return {
    type: 'Balanced Spender',
    title: 'The Balanced Manager ⚖️',
    tagline: 'Healthy equilibrium across meals, transit, coursework, and personal needs.',
    description: `No single category consumes more than 30% of your expenses. Your outlays are evenly distributed, demonstrating responsible student budget management.`,
    badgeColor: 'bg-indigo-100 text-indigo-800 border-indigo-200',
    accentBg: 'from-indigo-50 to-slate-50',
    keyMetric: 'Even Distribution',
    studentAdvice:
      'Tip: Your spending is balanced. Keep logging daily expenses to maintain this steady financial rhythm throughout the semester.',
    stats: {
      dominantPercentage: Math.round(Math.max(foodPct, academicPct, transportPct, entPct, shoppingPct)),
      transactionCount: activeExpenses.length,
      totalSpent,
    },
  };
}

export function computeBudgetProgress(expenses: Expense[], budgets: Budget[], monthStr: string = '2026-09'): CategoryBudgetProgress[] {
  const monthExpenses = expenses.filter((e) => e.date.startsWith(monthStr));

  const spentByCategory: Record<CategoryType, number> = {
    Food: 0,
    Transport: 0,
    Academic: 0,
    Entertainment: 0,
    Shopping: 0,
    Health: 0,
    Bills: 0,
    Other: 0,
  };

  for (const exp of monthExpenses) {
    spentByCategory[exp.category] = (spentByCategory[exp.category] || 0) + exp.amount;
  }

  return budgets.map((b) => {
    const spent = spentByCategory[b.category] || 0;
    const remaining = Math.max(0, b.monthlyLimit - spent);
    const percentageUsed = b.monthlyLimit > 0 ? Math.round((spent / b.monthlyLimit) * 100) : 0;

    let status: 'Safe' | 'Moderate' | 'Near Limit' | 'Exceeded' = 'Safe';
    if (percentageUsed >= 100) {
      status = 'Exceeded';
    } else if (percentageUsed >= 85) {
      status = 'Near Limit';
    } else if (percentageUsed >= 60) {
      status = 'Moderate';
    }

    return {
      category: b.category,
      monthlyLimit: b.monthlyLimit,
      spent,
      remaining,
      percentageUsed,
      status,
    };
  });
}

export function computeHeatmapCalendar(
  expenses: Expense[],
  year: number = 2026,
  month: number = 9
): {
  days: (DailySpending | null)[];
  maxDailySpend: number;
  highestDay: DailySpending | null;
  lowestDay: DailySpending | null;
  activeDays: number;
  streak: number;
} {
  const monthStr = `${year}-${String(month).padStart(2, '0')}`;
  const daysInMonth = new Date(year, month, 0).getDate();
  const firstDayWeekday = new Date(year, month - 1, 1).getDay(); // 0 = Sunday

  // Aggregate by day
  const dayTotals: Record<number, { amount: number; count: number }> = {};
  for (let d = 1; d <= daysInMonth; d++) {
    dayTotals[d] = { amount: 0, count: 0 };
  }

  for (const exp of expenses) {
    if (exp.date.startsWith(monthStr)) {
      const dayNum = parseInt(exp.date.split('-')[2], 10);
      if (dayTotals[dayNum]) {
        dayTotals[dayNum].amount += exp.amount;
        dayTotals[dayNum].count += 1;
      }
    }
  }

  // Calculate maximum daily spend for intensity scaling
  let maxDailySpend = 0;
  for (let d = 1; d <= daysInMonth; d++) {
    if (dayTotals[d].amount > maxDailySpend) {
      maxDailySpend = dayTotals[d].amount;
    }
  }

  // Build array with nulls for leading empty slots before 1st of month
  const days: (DailySpending | null)[] = [];
  for (let i = 0; i < firstDayWeekday; i++) {
    days.push(null);
  }

  let highestDay: DailySpending | null = null;
  let lowestDay: DailySpending | null = null;
  let activeDays = 0;
  let currentStreak = 0;
  let maxStreak = 0;

  for (let d = 1; d <= daysInMonth; d++) {
    const dayDate = new Date(year, month - 1, d);
    const dayOfWeek = dayDate.getDay();
    const isWeekend = dayOfWeek === 0 || dayOfWeek === 6;
    const amount = dayTotals[d].amount;
    const count = dayTotals[d].count;

    // Intensity: 0 = none, 1 = low, 2 = medium, 3 = high, 4 = intense
    let intensity: 0 | 1 | 2 | 3 | 4 = 0;
    if (amount > 0) {
      activeDays += 1;
      if (amount <= 150) intensity = 1;
      else if (amount <= 400) intensity = 2;
      else if (amount <= 850) intensity = 3;
      else intensity = 4;
    }

    const dayName = ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'][dayOfWeek];
    const item: DailySpending = {
      date: `${monthStr}-${String(d).padStart(2, '0')}`,
      dayOfMonth: d,
      dayName,
      amount,
      count,
      isWeekend,
      intensity,
    };

    days.push(item);

    if (amount > 0) {
      if (!highestDay || amount > highestDay.amount) {
        highestDay = item;
      }
      if (!lowestDay || amount < lowestDay.amount) {
        lowestDay = item;
      }
      currentStreak += 1;
      if (currentStreak > maxStreak) maxStreak = currentStreak;
    } else {
      currentStreak = 0;
    }
  }

  return {
    days,
    maxDailySpend,
    highestDay,
    lowestDay,
    activeDays,
    streak: maxStreak,
  };
}

export function computeWeekendVsWeekday(expenses: Expense[], monthStr: string = '2026-09'): WeekendVsWeekday {
  const monthExpenses = expenses.filter((e) => e.date.startsWith(monthStr));

  let weekendTotal = 0;
  let weekdayTotal = 0;
  const weekendDays = new Set<string>();
  const weekdayDays = new Set<string>();

  for (const exp of monthExpenses) {
    const d = new Date(exp.date);
    const day = d.getDay();
    if (day === 0 || day === 6) {
      weekendTotal += exp.amount;
      weekendDays.add(exp.date);
    } else {
      weekdayTotal += exp.amount;
      weekdayDays.add(exp.date);
    }
  }

  const total = weekendTotal + weekdayTotal;
  const weekendPercentage = total > 0 ? Math.round((weekendTotal / total) * 100) : 0;
  const weekdayPercentage = total > 0 ? Math.round((weekdayTotal / total) * 100) : 0;

  const weekendAvgPerDay = weekendDays.size > 0 ? Math.round(weekendTotal / weekendDays.size) : 0;
  const weekdayAvgPerDay = weekdayDays.size > 0 ? Math.round(weekdayTotal / weekdayDays.size) : 0;

  return {
    weekendTotal,
    weekdayTotal,
    weekendAvgPerDay,
    weekdayAvgPerDay,
    weekendPercentage,
    weekdayPercentage,
  };
}

export function generateSmartInsights(
  expenses: Expense[],
  budgets: Budget[],
  referenceDate: string = '2026-09-07'
): SmartInsight[] {
  const summary = computeSummary(expenses, referenceDate);
  const budgetProgress = computeBudgetProgress(expenses, budgets, '2026-09');
  const weekendData = computeWeekendVsWeekday(expenses, '2026-09');

  const insights: SmartInsight[] = [];

  // 1. Highest spending category insight
  if (summary.highestCategory !== 'None' && summary.highestCategoryAmount > 0) {
    insights.push({
      id: 'highest-cat',
      type: 'info',
      title: `${summary.highestCategory} leads your spending`,
      message: `${summary.highestCategory} is your largest expense group this month at ₹${summary.highestCategoryAmount.toLocaleString()} (${summary.highestCategoryPercentage}% of total).`,
      metric: `₹${summary.highestCategoryAmount.toLocaleString()}`,
      category: summary.highestCategory,
    });
  }

  // 2. Budget Alert
  const nearOrExceeded = budgetProgress.find((b) => b.status === 'Exceeded' || b.status === 'Near Limit');
  if (nearOrExceeded) {
    insights.push({
      id: 'budget-warning',
      type: nearOrExceeded.status === 'Exceeded' ? 'warning' : 'info',
      title: `${nearOrExceeded.category} Budget ${nearOrExceeded.status}`,
      message: `You have spent ₹${nearOrExceeded.spent.toLocaleString()} of your ₹${nearOrExceeded.monthlyLimit.toLocaleString()} limit (${nearOrExceeded.percentageUsed}% utilized).`,
      metric: `${nearOrExceeded.percentageUsed}%`,
      category: nearOrExceeded.category,
    });
  }

  // 3. Weekend vs Weekday analysis
  if (weekendData.weekendTotal > 0 || weekendData.weekdayTotal > 0) {
    if (weekendData.weekendAvgPerDay > weekendData.weekdayAvgPerDay * 1.3) {
      insights.push({
        id: 'weekend-surge',
        type: 'warning',
        title: 'Weekend Spending Spike',
        message: `Your average weekend spending (₹${weekendData.weekendAvgPerDay}/day) is ${Math.round(
          (weekendData.weekendAvgPerDay / Math.max(1, weekendData.weekdayAvgPerDay)) * 100 - 100
        )}% higher than your weekdays (₹${weekendData.weekdayAvgPerDay}/day).`,
        metric: `₹${weekendData.weekendAvgPerDay}/weekend day`,
      });
    } else {
      insights.push({
        id: 'weekday-steady',
        type: 'positive',
        title: 'Disciplined Weekend Spending',
        message: `Your weekend expenses remain modest at ${weekendData.weekendPercentage}% of your total outlays.`,
        metric: `${weekendData.weekendPercentage}% on weekends`,
      });
    }
  }

  // 4. Daily average observation
  if (summary.dailyAverageThisMonth > 0) {
    insights.push({
      id: 'daily-burn',
      type: 'tip',
      title: 'Current Daily Burn Rate',
      message: `You are spending an average of ₹${summary.dailyAverageThisMonth.toLocaleString()} per day through Day 7 of September.`,
      metric: `₹${summary.dailyAverageThisMonth}/day`,
    });
  }

  return insights;
}
