import { Expense, ExpenseAnomaly, CategoryType } from '../types';

export function detectAnomalies(expenses: Expense[]): ExpenseAnomaly[] {
  if (!expenses || expenses.length < 3) return [];

  // Group by category
  const byCategory: Record<CategoryType, Expense[]> = {
    Food: [],
    Transport: [],
    Academic: [],
    Entertainment: [],
    Shopping: [],
    Health: [],
    Bills: [],
    Other: [],
  };

  for (const exp of expenses) {
    if (byCategory[exp.category]) {
      byCategory[exp.category].push(exp);
    }
  }

  const anomalies: ExpenseAnomaly[] = [];

  for (const [catStr, list] of Object.entries(byCategory)) {
    const category = catStr as CategoryType;
    if (list.length < 2) continue;

    const amounts = list.map((e) => e.amount);
    const sum = amounts.reduce((a, b) => a + b, 0);
    const mean = sum / amounts.length;

    // Standard deviation
    const variance = amounts.reduce((acc, val) => acc + Math.pow(val - mean, 2), 0) / amounts.length;
    const stdDev = Math.sqrt(variance);

    for (const exp of list) {
      const diff = exp.amount - mean;
      const ratio = mean > 0 ? exp.amount / mean : 1;

      // Anomaly criteria:
      // 1. Amount is at least 2.2x the category mean AND absolute difference is >= ₹200
      // OR 2. z-score > 2.0 AND diff >= ₹250
      const isRatioAnomaly = ratio >= 2.2 && diff >= 200;
      const isZAnomaly = stdDev > 0 && (exp.amount - mean) / stdDev >= 2.0 && diff >= 250;

      if (isRatioAnomaly || isZAnomaly) {
        let severity: 'moderate' | 'high' | 'extreme' = 'moderate';
        if (ratio >= 4.0 || diff >= 1500) {
          severity = 'extreme';
        } else if (ratio >= 2.8 || diff >= 600) {
          severity = 'high';
        }

        const formattedDiff = Math.round(diff);
        const formattedAvg = Math.round(mean);
        const message = `₹${exp.amount.toLocaleString()} is ${ratio.toFixed(1)}x higher than your average ${category} spending of ₹${formattedAvg} (+₹${formattedDiff}).`;

        anomalies.push({
          expense: exp,
          categoryAverage: formattedAvg,
          differenceFromAvg: formattedDiff,
          ratioToAvg: parseFloat(ratio.toFixed(1)),
          severity,
          message,
        });
      }
    }
  }

  // Sort descending by ratio to average
  return anomalies.sort((a, b) => b.ratioToAvg - a.ratioToAvg);
}
