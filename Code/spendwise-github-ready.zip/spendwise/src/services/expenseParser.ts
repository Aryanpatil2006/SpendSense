import { CategoryType, ParsedExpenseResult, PaymentMethod } from '../types';
import { CATEGORIES, ALL_CATEGORIES } from '../data/categories';

export function detectCategoryFromText(text: string): { category: CategoryType; matchedKeywords: string[] } {
  const lower = text.toLowerCase();
  const matchedKeywords: string[] = [];

  let bestCategory: CategoryType = 'Other';
  let maxScore = 0;

  for (const cat of ALL_CATEGORIES) {
    const meta = CATEGORIES[cat];
    let score = 0;
    for (const kw of meta.keywords) {
      // Check for word boundary or substring
      const regex = new RegExp(`\\b${kw}\\b`, 'i');
      if (regex.test(lower)) {
        score += 2;
        matchedKeywords.push(kw);
      } else if (lower.includes(kw)) {
        score += 1;
        matchedKeywords.push(kw);
      }
    }

    if (score > maxScore) {
      maxScore = score;
      bestCategory = cat;
    }
  }

  return {
    category: bestCategory,
    matchedKeywords: Array.from(new Set(matchedKeywords)),
  };
}

export function parseNaturalExpense(input: string, referenceDate: string = '2026-09-07'): ParsedExpenseResult {
  if (!input || !input.trim()) {
    return {
      amount: null,
      description: '',
      category: 'Other',
      date: referenceDate,
      paymentMethod: 'UPI',
      rawText: input,
      confidence: 0,
      matchedKeywords: [],
    };
  }

  let text = input.trim();
  let detectedAmount: number | null = null;
  let detectedPaymentMethod: PaymentMethod = 'UPI';
  let detectedDate = referenceDate;

  // 1. Detect Payment Method
  if (/\b(cash|notes|coins)\b/i.test(text)) {
    detectedPaymentMethod = 'Cash';
  } else if (/\b(debit card|debit|atm card)\b/i.test(text)) {
    detectedPaymentMethod = 'Debit Card';
  } else if (/\b(credit card|credit)\b/i.test(text)) {
    detectedPaymentMethod = 'Credit Card';
  } else if (/\b(net banking|netbanking|bank transfer|neft|imps)\b/i.test(text)) {
    detectedPaymentMethod = 'Net Banking';
  } else if (/\b(upi|gpay|google pay|phonepe|paytm|bhim)\b/i.test(text)) {
    detectedPaymentMethod = 'UPI';
  }

  // 2. Detect Relative Date
  if (/\byesterday\b/i.test(text)) {
    const d = new Date(referenceDate);
    d.setDate(d.getDate() - 1);
    detectedDate = d.toISOString().split('T')[0];
    text = text.replace(/\byesterday\b/gi, ' ');
  } else if (/\btoday\b/i.test(text)) {
    detectedDate = referenceDate;
    text = text.replace(/\btoday\b/gi, ' ');
  }

  // 3. Extract Amount: Matches ₹120, 120rs, Rs. 120, INR 120, or standalone numbers
  // Pattern 1: Symbol prefixed: ₹\s*(\d+(\.\d{1,2})?) or Rs\.?\s*(\d+(\.\d{1,2})?)
  const symbolMatch = text.match(/(?:₹|rs\.?|inr|\$)\s*([0-9]+(?:\.[0-9]{1,2})?)/i);
  if (symbolMatch) {
    detectedAmount = parseFloat(symbolMatch[1]);
    text = text.replace(symbolMatch[0], ' ');
  } else {
    // Pattern 2: Suffix: (\d+(\.\d{1,2})?)\s*(?:rs|rupees|inr|bucks)
    const suffixMatch = text.match(/([0-9]+(?:\.[0-9]{1,2})?)\s*(?:rs|rupees|inr|bucks)\b/i);
    if (suffixMatch) {
      detectedAmount = parseFloat(suffixMatch[1]);
      text = text.replace(suffixMatch[0], ' ');
    } else {
      // Pattern 3: Standalone number: either at start, end, or isolated
      const numMatch = text.match(/\b([0-9]+(?:\.[0-9]{1,2})?)\b/);
      if (numMatch) {
        detectedAmount = parseFloat(numMatch[1]);
        text = text.replace(numMatch[0], ' ');
      }
    }
  }

  // Clean filler words
  text = text
    .replace(/\b(spent|paid|for|at|on|via|using|by|bought|purchased|got|with)\b/gi, ' ')
    .replace(/\s+/g, ' ')
    .trim();

  // 4. Categorization
  const { category, matchedKeywords } = detectCategoryFromText(input);

  // Capitalize description nicely
  let description = text.length > 0 ? text : (matchedKeywords.length > 0 ? `${matchedKeywords[0]} expense` : 'General expense');
  description = description.charAt(0).toUpperCase() + description.slice(1);

  // Calculate confidence
  let confidence = 0;
  if (detectedAmount !== null && detectedAmount > 0) confidence += 50;
  if (matchedKeywords.length > 0) confidence += 30;
  if (description.length > 3) confidence += 20;

  return {
    amount: detectedAmount,
    description,
    category,
    date: detectedDate,
    paymentMethod: detectedPaymentMethod,
    rawText: input,
    confidence,
    matchedKeywords,
  };
}
