import React, { useMemo } from 'react';
import {
  Wallet,
  Calendar,
  Sparkles,
  TrendingUp,
  AlertTriangle,
  ArrowRight,
  PlusCircle,
  Clock,
  PieChart,
  BarChart3,
  Award,
  ShieldCheck,
  Zap,
} from 'lucide-react';
import { Expense, Budget, CategoryType } from '../types';
import { CATEGORIES } from '../data/categories';
import {
  computeSummary,
  computeSpendingPersonality,
  computeCategoryDistribution,
  computeBudgetProgress,
  computeHeatmapCalendar,
  generateSmartInsights,
} from '../services/analyticsEngine';
import { detectAnomalies } from '../services/anomalyDetector';
import { ActiveTab } from './Navbar';

interface DashboardProps {
  expenses: Expense[];
  budgets: Budget[];
  setActiveTab: (tab: ActiveTab) => void;
  onEditExpense: (expense: Expense) => void;
}

export const Dashboard: React.FC<DashboardProps> = ({
  expenses,
  budgets,
  setActiveTab,
  onEditExpense,
}) => {
  const referenceDate = '2026-09-07';

  const summary = useMemo(() => computeSummary(expenses, referenceDate), [expenses]);
  const personality = useMemo(() => computeSpendingPersonality(expenses, budgets, '2026-09'), [
    expenses,
    budgets,
  ]);
  const anomalies = useMemo(() => detectAnomalies(expenses), [expenses]);
  const categoryDist = useMemo(() => computeCategoryDistribution(expenses, '2026-09'), [expenses]);
  const budgetProgress = useMemo(() => computeBudgetProgress(expenses, budgets, '2026-09'), [
    expenses,
    budgets,
  ]);
  const heatmap = useMemo(() => computeHeatmapCalendar(expenses, 2026, 9), [expenses]);
  const insights = useMemo(() => generateSmartInsights(expenses, budgets, referenceDate), [
    expenses,
    budgets,
  ]);

  // Recent 5 transactions
  const recentExpenses = useMemo(() => {
    return [...expenses]
      .sort((a, b) => b.date.localeCompare(a.date) || b.createdAt - a.createdAt)
      .slice(0, 5);
  }, [expenses]);

  // Daily bar chart for Sep 1-7
  const dailyData = useMemo(() => {
    const map = new Map<string, number>();
    for (const e of expenses) {
      if (e.date.startsWith('2026-09')) {
        map.set(e.date, (map.get(e.date) || 0) + e.amount);
      }
    }
    const days = [];
    for (let d = 1; d <= 7; d++) {
      const dateStr = `2026-09-0${d}`;
      const dt = new Date(dateStr + 'T12:00:00');
      days.push({
        day: dt.toLocaleDateString('en-US', { weekday: 'narrow' }),
        date: d,
        amount: map.get(dateStr) || 0,
      });
    }
    return days;
  }, [expenses]);

  const maxDaily = Math.max(...dailyData.map((d) => d.amount), 500);

  return (
    <div className="space-y-6">
      {/* Student Welcome Banner */}
      <div className="bg-gradient-to-r from-indigo-900 via-indigo-800 to-slate-900 rounded-2xl p-6 sm:p-7 text-white shadow-md flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <div className="flex items-center space-x-2">
            <span className="px-2.5 py-0.5 rounded-full text-[10px] font-extrabold uppercase tracking-wider bg-indigo-500/30 text-indigo-200 border border-indigo-400/30">
              Fall Semester 2026
            </span>
            <span className="text-xs text-indigo-200">
              Monday, 07 September 2026
            </span>
          </div>
          <h1 className="text-2xl sm:text-3xl font-black tracking-tight mt-1">
            Welcome back, Student! 👋
          </h1>
          <p className="text-xs sm:text-sm text-indigo-100/90 mt-1 max-w-xl">
            You have logged <strong className="text-white">{summary.transactionCount} transactions</strong> across 8 categories. Your current spending profile is classified as <strong className="text-white">{personality.title}</strong>.
          </p>
        </div>

        <div className="flex flex-wrap items-center gap-2">
          <button
            onClick={() => setActiveTab('logger')}
            className="px-4 py-2.5 rounded-xl bg-white text-indigo-900 hover:bg-indigo-50 text-xs font-bold flex items-center space-x-2 shadow-xs transition cursor-pointer"
          >
            <PlusCircle className="w-4 h-4 text-indigo-600" />
            <span>Quick Log Expense</span>
          </button>
          <button
            onClick={() => setActiveTab('analytics')}
            className="px-3.5 py-2.5 rounded-xl bg-indigo-700/60 hover:bg-indigo-700 text-white text-xs font-semibold border border-indigo-500/40 transition flex items-center space-x-1.5 cursor-pointer"
          >
            <span>Spending Analytics</span>
            <ArrowRight className="w-3.5 h-3.5" />
          </button>
        </div>
      </div>

      {/* Top 5 Summary Cards */}
      <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-5 gap-3 sm:gap-4">
        {/* Card 1: Total Spending */}
        <div className="bg-white rounded-2xl p-4 sm:p-5 border border-slate-200 shadow-xs">
          <span className="text-[10px] uppercase font-bold text-slate-400 block tracking-wider">
            Total All-Time Spend
          </span>
          <span className="text-xl sm:text-2xl font-black text-slate-900 mt-1 block">
            ₹{summary.totalSpent.toLocaleString()}
          </span>
          <span className="text-[11px] text-slate-500 mt-1 block">
            Across {summary.transactionCount} total logs
          </span>
        </div>

        {/* Card 2: Today's Spending */}
        <div className="bg-white rounded-2xl p-4 sm:p-5 border border-slate-200 shadow-xs">
          <span className="text-[10px] uppercase font-bold text-slate-400 block tracking-wider">
            Today's Outflow (Sep 7)
          </span>
          <span className="text-xl sm:text-2xl font-black text-indigo-700 mt-1 block">
            ₹{summary.todaySpent.toLocaleString()}
          </span>
          <span className="text-[11px] text-slate-500 mt-1 block">
            Daily limit target: ₹450
          </span>
        </div>

        {/* Card 3: This Month */}
        <div className="bg-white rounded-2xl p-4 sm:p-5 border border-slate-200 shadow-xs">
          <span className="text-[10px] uppercase font-bold text-slate-400 block tracking-wider">
            September 2026
          </span>
          <span className="text-xl sm:text-2xl font-black text-slate-900 mt-1 block">
            ₹{summary.thisMonthSpent.toLocaleString()}
          </span>
          <div className="flex items-center space-x-1 mt-1">
            <span className="text-[10px] font-bold text-emerald-600">
              Avg ₹{summary.dailyAverageThisMonth}/day
            </span>
          </div>
        </div>

        {/* Card 4: Highest Category */}
        <div className="bg-white rounded-2xl p-4 sm:p-5 border border-slate-200 shadow-xs">
          <span className="text-[10px] uppercase font-bold text-slate-400 block tracking-wider">
            Top Category
          </span>
          <div className="flex items-center space-x-1.5 mt-1">
            <span className="text-xl">
              {summary.highestCategory !== 'None' ? CATEGORIES[summary.highestCategory]?.emoji : '—'}
            </span>
            <span className="text-base sm:text-lg font-black text-slate-900 truncate">
              {summary.highestCategory}
            </span>
          </div>
          <span className="text-[11px] font-semibold text-slate-500 mt-1 block">
            ₹{summary.highestCategoryAmount.toLocaleString()} ({summary.highestCategoryPercentage}%)
          </span>
        </div>

        {/* Card 5: Transactions Count */}
        <div className="bg-white rounded-2xl p-4 sm:p-5 border border-slate-200 shadow-xs col-span-2 sm:col-span-1">
          <span className="text-[10px] uppercase font-bold text-slate-400 block tracking-wider">
            Logging Velocity
          </span>
          <span className="text-xl sm:text-2xl font-black text-slate-900 mt-1 block">
            {summary.activeDaysCount} Days
          </span>
          <span className="text-[11px] text-slate-500 mt-1 block">
            Streak: {heatmap.streak} days active
          </span>
        </div>
      </div>

      {/* Anomaly Detector Alert Banner */}
      {anomalies.length > 0 && (
        <div className="bg-rose-50 border border-rose-200 rounded-2xl p-4 sm:p-5 flex flex-col sm:flex-row sm:items-center justify-between gap-3 animate-fade-in">
          <div className="flex items-start space-x-3">
            <span className="p-2 rounded-xl bg-rose-100 text-rose-700 shrink-0">
              <AlertTriangle className="w-5 h-5" />
            </span>
            <div>
              <div className="flex items-center space-x-2">
                <span className="text-xs font-extrabold uppercase tracking-wider text-rose-900">
                  Unusual Expense Detected
                </span>
                <span className="px-2 py-0.2 rounded-full text-[10px] font-bold bg-rose-200 text-rose-900">
                  Analytical Alert
                </span>
              </div>
              <p className="text-xs text-rose-800 mt-0.5 leading-relaxed">
                ₹{anomalies[0].expense.amount.toLocaleString()} for "{anomalies[0].expense.description}" on {anomalies[0].expense.date} is {anomalies[0].ratioToAvg}x higher than your average {anomalies[0].expense.category} baseline (₹{anomalies[0].categoryAverage}).
              </p>
            </div>
          </div>

          <button
            onClick={() => setActiveTab('analytics')}
            className="px-3.5 py-1.5 rounded-lg bg-rose-600 hover:bg-rose-700 text-white text-xs font-bold shrink-0 self-start sm:self-auto transition cursor-pointer"
          >
            Review Anomalies
          </button>
        </div>
      )}

      {/* Personality & Insights Strip */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Spending Personality Card (1 Col) */}
        <div className={`rounded-2xl p-6 bg-gradient-to-br ${personality.accentBg} border border-slate-200 shadow-xs flex flex-col justify-between space-y-4`}>
          <div>
            <div className="flex items-center justify-between">
              <span className="text-[10px] uppercase font-bold text-slate-500 tracking-wider">
                Your Spending Personality
              </span>
              <span className={`px-2 py-0.5 rounded-full text-[10px] font-extrabold border ${personality.badgeColor}`}>
                {personality.type}
              </span>
            </div>

            <h3 className="text-xl font-extrabold text-slate-900 mt-2">
              {personality.title}
            </h3>
            <p className="text-xs text-slate-600 font-medium mt-0.5 italic">
              {personality.tagline}
            </p>
            <p className="text-xs text-slate-700 mt-2 leading-relaxed">
              {personality.description}
            </p>
          </div>

          <div className="pt-3 border-t border-slate-200/60 flex items-center justify-between">
            <span className="text-xs font-bold text-slate-700">{personality.keyMetric}</span>
            <button
              onClick={() => setActiveTab('analytics')}
              className="text-xs font-extrabold text-indigo-700 hover:text-indigo-900 flex items-center gap-1 transition"
            >
              <span>Explore Analytics</span>
              <ArrowRight className="w-3.5 h-3.5" />
            </button>
          </div>
        </div>

        {/* Smart Insights (2 Cols) */}
        <div className="lg:col-span-2 bg-white rounded-2xl p-6 border border-slate-200 shadow-xs space-y-3">
          <div className="flex items-center justify-between">
            <h3 className="text-sm font-bold text-slate-900 flex items-center gap-1.5">
              <Sparkles className="w-4 h-4 text-indigo-600" />
              <span>Smart Student Insights</span>
            </h3>
            <span className="text-[10px] font-bold text-slate-400 uppercase">
              Calculated from Stored Records
            </span>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            {insights.slice(0, 4).map((ins) => (
              <div
                key={ins.id}
                className="p-3.5 rounded-xl border border-slate-200 bg-slate-50/70 hover:bg-slate-50 transition space-y-1"
              >
                <div className="flex items-center justify-between">
                  <span className="text-xs font-bold text-slate-800">{ins.title}</span>
                  {ins.metric && (
                    <span className="text-[10px] font-extrabold px-1.5 py-0.5 rounded bg-white text-indigo-700 border border-slate-200">
                      {ins.metric}
                    </span>
                  )}
                </div>
                <p className="text-[11px] text-slate-600 leading-relaxed">{ins.message}</p>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Interactive Charts: Category Donut & Daily Spend Bar */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Category Donut */}
        <div className="bg-white rounded-2xl p-6 border border-slate-200 shadow-xs space-y-4">
          <div className="flex items-center justify-between">
            <h3 className="text-sm font-bold text-slate-900 flex items-center gap-2">
              <PieChart className="w-4 h-4 text-indigo-600" />
              <span>September Category Distribution</span>
            </h3>
            <button
              onClick={() => setActiveTab('analytics')}
              className="text-xs font-bold text-indigo-600 hover:text-indigo-800"
            >
              Full Details →
            </button>
          </div>

          <div className="space-y-2.5">
            {categoryDist.slice(0, 5).map((item) => {
              const meta = CATEGORIES[item.category];
              return (
                <div key={item.category} className="space-y-1">
                  <div className="flex items-center justify-between text-xs">
                    <span className="font-semibold text-slate-700 flex items-center gap-1.5">
                      <span>{meta.emoji}</span>
                      <span>{item.category}</span>
                    </span>
                    <span className="font-extrabold text-slate-900">
                      ₹{item.amount.toLocaleString()} ({item.percentage}%)
                    </span>
                  </div>
                  <div className="w-full h-2 rounded-full bg-slate-100 overflow-hidden">
                    <div
                      className="h-full rounded-full transition-all duration-500"
                      style={{
                        width: `${item.percentage}%`,
                        backgroundColor: meta.color,
                      }}
                    />
                  </div>
                </div>
              );
            })}
          </div>
        </div>

        {/* Daily Velocity Bar Chart */}
        <div className="bg-white rounded-2xl p-6 border border-slate-200 shadow-xs space-y-4">
          <div className="flex items-center justify-between">
            <h3 className="text-sm font-bold text-slate-900 flex items-center gap-2">
              <BarChart3 className="w-4 h-4 text-indigo-600" />
              <span>September Daily Spend Velocity (Day 1–7)</span>
            </h3>
            <span className="text-[11px] text-slate-500">
              Avg: ₹{summary.dailyAverageThisMonth}/day
            </span>
          </div>

          <div className="h-44 flex items-end justify-between gap-3 pt-6 pb-2">
            {dailyData.map((d) => {
              const h = maxDaily > 0 ? (d.amount / maxDaily) * 100 : 0;
              return (
                <div key={d.date} className="flex-1 flex flex-col items-center h-full justify-end group">
                  <span className="text-[10px] font-bold text-slate-700 opacity-0 group-hover:opacity-100 transition mb-1">
                    ₹{d.amount}
                  </span>
                  <div className="w-full max-w-[28px] bg-slate-100 rounded-t-lg h-full flex items-end">
                    <div
                      className="w-full rounded-t-lg bg-indigo-600 transition-all duration-500 group-hover:bg-indigo-700"
                      style={{ height: `${Math.max(6, h)}%` }}
                    />
                  </div>
                  <span className="text-[10px] font-bold text-slate-600 mt-2">
                    Sep {d.date}
                  </span>
                </div>
              );
            })}
          </div>
        </div>
      </div>

      {/* Heatmap & Recent Logs Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Heatmap Mini Preview */}
        <div className="bg-white rounded-2xl p-6 border border-slate-200 shadow-xs space-y-4">
          <div className="flex items-center justify-between">
            <h3 className="text-sm font-bold text-slate-900 flex items-center gap-2">
              <Calendar className="w-4 h-4 text-indigo-600" />
              <span>September Expense Heatmap</span>
            </h3>
            <button
              onClick={() => setActiveTab('heatmap')}
              className="text-xs font-bold text-indigo-600 hover:text-indigo-800"
            >
              Interactive Heatmap →
            </button>
          </div>

          <p className="text-xs text-slate-500">
            Current streak: <strong className="text-indigo-700 font-bold">{heatmap.streak} days</strong> tracked. Days with higher spending are shaded with greater color intensity.
          </p>

          {/* Mini Calendar Row for First 14 days */}
          <div className="grid grid-cols-7 gap-1.5 text-center text-xs">
            {['S', 'M', 'T', 'W', 'T', 'F', 'S'].map((day, idx) => (
              <span key={idx} className="text-[10px] font-bold text-slate-400 uppercase">
                {day}
              </span>
            ))}

            {heatmap.days.slice(0, 14).map((dayItem, idx) => {
              if (!dayItem) {
                return <div key={idx} className="h-9 rounded-lg bg-slate-50/50" />;
              }
              const bg =
                dayItem.intensity === 4
                  ? 'bg-rose-200 text-rose-950 font-bold'
                  : dayItem.intensity === 3
                  ? 'bg-orange-200 text-orange-950 font-bold'
                  : dayItem.intensity === 2
                  ? 'bg-amber-100 text-amber-900 font-bold'
                  : dayItem.intensity === 1
                  ? 'bg-emerald-100 text-emerald-900 font-semibold'
                  : 'bg-slate-100 text-slate-400';

              return (
                <div
                  key={dayItem.date}
                  className={`h-9 rounded-lg flex flex-col items-center justify-center p-1 ${bg}`}
                  title={`${dayItem.date}: ₹${dayItem.amount}`}
                >
                  <span className="text-[11px] leading-none">{dayItem.dayOfMonth}</span>
                  {dayItem.amount > 0 && (
                    <span className="text-[8px] opacity-80 mt-0.5">₹{dayItem.amount}</span>
                  )}
                </div>
              );
            })}
          </div>
        </div>

        {/* Recent Transactions List */}
        <div className="bg-white rounded-2xl p-6 border border-slate-200 shadow-xs space-y-4">
          <div className="flex items-center justify-between">
            <h3 className="text-sm font-bold text-slate-900 flex items-center gap-2">
              <Clock className="w-4 h-4 text-indigo-600" />
              <span>Recent Expense Logs</span>
            </h3>
            <button
              onClick={() => setActiveTab('logs')}
              className="text-xs font-bold text-indigo-600 hover:text-indigo-800"
            >
              View Full Timeline ({expenses.length}) →
            </button>
          </div>

          <div className="space-y-2.5">
            {recentExpenses.map((exp) => {
              const meta = CATEGORIES[exp.category];
              return (
                <div
                  key={exp.id}
                  onClick={() => onEditExpense(exp)}
                  className="p-3 rounded-xl border border-slate-200 hover:border-slate-300 hover:bg-slate-50/60 transition flex items-center justify-between cursor-pointer"
                >
                  <div className="flex items-center space-x-3 overflow-hidden">
                    <span className="text-xl p-1.5 rounded-lg bg-slate-50 border border-slate-200 shrink-0">
                      {meta.emoji}
                    </span>
                    <div className="truncate">
                      <span className="text-xs font-bold text-slate-900 block truncate">
                        {exp.description}
                      </span>
                      <span className="text-[10px] text-slate-500">
                        {exp.date} • {exp.category} • {exp.paymentMethod}
                      </span>
                    </div>
                  </div>

                  <span className="text-xs font-extrabold text-slate-900 shrink-0 ml-2">
                    ₹{exp.amount.toLocaleString()}
                  </span>
                </div>
              );
            })}
          </div>
        </div>
      </div>
    </div>
  );
};
