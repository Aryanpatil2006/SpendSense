import React, { useState, useMemo } from 'react';
import {
  Calendar as CalendarIcon,
  Flame,
  TrendingUp,
  Award,
  ChevronLeft,
  ChevronRight,
  Info,
  CreditCard,
  Utensils,
} from 'lucide-react';
import { Expense } from '../types';
import {
  computeHeatmapCalendar,
  computeWeekendVsWeekday,
  DailySpending,
} from '../services/analyticsEngine';
import { CATEGORIES } from '../data/categories';

interface ExpenseHeatmapProps {
  expenses: Expense[];
  onSelectDay?: (date: string) => void;
}

export const ExpenseHeatmap: React.FC<ExpenseHeatmapProps> = ({ expenses }) => {
  const [selectedYear, setSelectedYear] = useState(2026);
  const [selectedMonth, setSelectedMonth] = useState(9); // September
  const [inspectedDay, setInspectedDay] = useState<DailySpending | null>(null);

  const monthStr = `${selectedYear}-${String(selectedMonth).padStart(2, '0')}`;
  const monthName = new Date(selectedYear, selectedMonth - 1, 1).toLocaleDateString('en-US', {
    month: 'long',
    year: 'numeric',
  });

  const heatmapData = useMemo(() => {
    return computeHeatmapCalendar(expenses, selectedYear, selectedMonth);
  }, [expenses, selectedYear, selectedMonth]);

  const weekendData = useMemo(() => {
    return computeWeekendVsWeekday(expenses, monthStr);
  }, [expenses, monthStr]);

  // Expenses for currently inspected day
  const inspectedExpenses = useMemo(() => {
    if (!inspectedDay) return [];
    return expenses.filter((e) => e.date === inspectedDay.date);
  }, [expenses, inspectedDay]);

  const handlePrevMonth = () => {
    if (selectedMonth === 1) {
      setSelectedMonth(12);
      setSelectedYear(selectedYear - 1);
    } else {
      setSelectedMonth(selectedMonth - 1);
    }
    setInspectedDay(null);
  };

  const handleNextMonth = () => {
    if (selectedMonth === 12) {
      setSelectedMonth(1);
      setSelectedYear(selectedYear + 1);
    } else {
      setSelectedMonth(selectedMonth + 1);
    }
    setInspectedDay(null);
  };

  const getIntensityClass = (intensity: 0 | 1 | 2 | 3 | 4) => {
    switch (intensity) {
      case 1:
        return 'bg-emerald-100 border-emerald-300 text-emerald-900 hover:bg-emerald-200';
      case 2:
        return 'bg-amber-100 border-amber-300 text-amber-900 hover:bg-amber-200';
      case 3:
        return 'bg-orange-200 border-orange-400 text-orange-950 hover:bg-orange-300';
      case 4:
        return 'bg-rose-200 border-rose-400 text-rose-950 hover:bg-rose-300 ring-2 ring-rose-400/30';
      default:
        return 'bg-slate-50 border-slate-200 text-slate-400 hover:bg-slate-100';
    }
  };

  return (
    <div className="space-y-6">
      {/* Heatmap Header */}
      <div className="bg-white rounded-2xl p-6 border border-slate-200 shadow-xs">
        <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
          <div>
            <div className="flex items-center space-x-2">
              <span className="p-2 rounded-xl bg-orange-50 text-orange-600 border border-orange-200">
                <Flame className="w-5 h-5" />
              </span>
              <h1 className="text-2xl font-extrabold text-slate-900 tracking-tight">
                Expense Heatmap Calendar
              </h1>
            </div>
            <p className="text-sm text-slate-600 mt-1">
              Visualize spending velocity across days, identify high-burn spikes, and track habits.
            </p>
          </div>

          {/* Month Navigation */}
          <div className="flex items-center space-x-2 bg-slate-100 p-1.5 rounded-xl border border-slate-200">
            <button
              onClick={handlePrevMonth}
              className="p-1.5 rounded-lg hover:bg-white text-slate-600 transition"
              title="Previous Month"
            >
              <ChevronLeft className="w-4 h-4" />
            </button>
            <span className="text-xs font-extrabold text-slate-800 px-3 min-w-[120px] text-center">
              {monthName}
            </span>
            <button
              onClick={handleNextMonth}
              className="p-1.5 rounded-lg hover:bg-white text-slate-600 transition"
              title="Next Month"
            >
              <ChevronRight className="w-4 h-4" />
            </button>
          </div>
        </div>

        {/* Highlights Row */}
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 mt-6">
          <div className="p-3.5 bg-slate-50 rounded-xl border border-slate-200">
            <span className="text-[10px] uppercase font-bold text-slate-400 block">Peak Spend Day</span>
            <span className="text-sm font-extrabold text-rose-700 mt-1 block">
              {heatmapData.highestDay
                ? `Day ${heatmapData.highestDay.dayOfMonth} (₹${heatmapData.highestDay.amount.toLocaleString()})`
                : 'No data'}
            </span>
            <span className="text-[10px] text-slate-500">Highest daily outflow</span>
          </div>

          <div className="p-3.5 bg-slate-50 rounded-xl border border-slate-200">
            <span className="text-[10px] uppercase font-bold text-slate-400 block">Frugal / Low Day</span>
            <span className="text-sm font-extrabold text-emerald-700 mt-1 block">
              {heatmapData.lowestDay
                ? `Day ${heatmapData.lowestDay.dayOfMonth} (₹${heatmapData.lowestDay.amount.toLocaleString()})`
                : 'No data'}
            </span>
            <span className="text-[10px] text-slate-500">Lowest non-zero outlay</span>
          </div>

          <div className="p-3.5 bg-slate-50 rounded-xl border border-slate-200">
            <span className="text-[10px] uppercase font-bold text-slate-400 block">Active Logging Streak</span>
            <span className="text-sm font-extrabold text-indigo-700 mt-1 block flex items-center gap-1">
              <Award className="w-4 h-4 text-indigo-500" />
              {heatmapData.streak} Days
            </span>
            <span className="text-[10px] text-slate-500">Consecutive tracked days</span>
          </div>

          <div className="p-3.5 bg-slate-50 rounded-xl border border-slate-200">
            <span className="text-[10px] uppercase font-bold text-slate-400 block">Weekend vs Weekday</span>
            <span className="text-sm font-extrabold text-slate-900 mt-1 block">
              {weekendData.weekendPercentage}% Weekend
            </span>
            <span className="text-[10px] text-slate-500">
              Avg: ₹{weekendData.weekendAvgPerDay}/day vs ₹{weekendData.weekdayAvgPerDay}/day
            </span>
          </div>
        </div>
      </div>

      {/* Main Grid & Details Section */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Calendar Grid (2 Cols on lg) */}
        <div className="lg:col-span-2 bg-white rounded-2xl p-6 border border-slate-200 shadow-xs space-y-4">
          <div className="flex items-center justify-between">
            <span className="text-xs font-bold uppercase tracking-wider text-slate-700 flex items-center gap-1.5">
              <CalendarIcon className="w-4 h-4 text-indigo-600" />
              Daily Intensity Grid — {monthName}
            </span>
            <span className="text-[11px] text-slate-500 font-medium">Click any day to view logs</span>
          </div>

          {/* Weekday Labels */}
          <div className="grid grid-cols-7 gap-2 text-center text-[11px] font-bold text-slate-400 uppercase tracking-wider">
            <span>Sun</span>
            <span>Mon</span>
            <span>Tue</span>
            <span>Wed</span>
            <span>Thu</span>
            <span>Fri</span>
            <span>Sat</span>
          </div>

          {/* Calendar Days */}
          <div className="grid grid-cols-7 gap-2">
            {heatmapData.days.map((item, index) => {
              if (!item) {
                return (
                  <div
                    key={`empty-${index}`}
                    className="h-16 sm:h-20 rounded-xl bg-slate-50/50 border border-transparent opacity-40"
                  />
                );
              }

              const isSelected = inspectedDay?.date === item.date;

              return (
                <button
                  key={item.date}
                  type="button"
                  onClick={() => setInspectedDay(item)}
                  className={`h-16 sm:h-20 p-1.5 sm:p-2 rounded-xl border text-left flex flex-col justify-between transition cursor-pointer relative ${getIntensityClass(
                    item.intensity
                  )} ${isSelected ? 'ring-3 ring-indigo-500 shadow-md' : ''}`}
                >
                  <div className="flex items-center justify-between w-full">
                    <span
                      className={`text-xs font-bold ${
                        item.amount > 0 ? 'text-slate-900' : 'text-slate-400'
                      }`}
                    >
                      {item.dayOfMonth}
                    </span>
                    {item.isWeekend && (
                      <span className="text-[9px] font-semibold text-slate-400 hidden sm:inline">Wknd</span>
                    )}
                  </div>

                  <div className="mt-auto">
                    {item.amount > 0 ? (
                      <div>
                        <span className="text-[11px] sm:text-xs font-extrabold block truncate">
                          ₹{item.amount.toLocaleString()}
                        </span>
                        <span className="text-[9px] font-medium opacity-75 hidden sm:block">
                          {item.count} {item.count === 1 ? 'item' : 'items'}
                        </span>
                      </div>
                    ) : (
                      <span className="text-[10px] text-slate-400 block font-normal">—</span>
                    )}
                  </div>
                </button>
              );
            })}
          </div>

          {/* Heatmap Legend */}
          <div className="pt-3 border-t border-slate-100 flex flex-wrap items-center justify-between gap-3 text-xs">
            <span className="text-slate-500 font-semibold text-[11px]">Intensity Scale:</span>
            <div className="flex items-center space-x-2">
              <div className="flex items-center space-x-1.5">
                <span className="w-3.5 h-3.5 rounded-md bg-slate-100 border border-slate-300"></span>
                <span className="text-[11px] text-slate-600">₹0</span>
              </div>
              <div className="flex items-center space-x-1.5">
                <span className="w-3.5 h-3.5 rounded-md bg-emerald-100 border border-emerald-300"></span>
                <span className="text-[11px] text-slate-600">Low (≤₹150)</span>
              </div>
              <div className="flex items-center space-x-1.5">
                <span className="w-3.5 h-3.5 rounded-md bg-amber-100 border border-amber-300"></span>
                <span className="text-[11px] text-slate-600">Med (≤₹400)</span>
              </div>
              <div className="flex items-center space-x-1.5">
                <span className="w-3.5 h-3.5 rounded-md bg-orange-200 border border-orange-400"></span>
                <span className="text-[11px] text-slate-600">High (≤₹850)</span>
              </div>
              <div className="flex items-center space-x-1.5">
                <span className="w-3.5 h-3.5 rounded-md bg-rose-200 border border-rose-400"></span>
                <span className="text-[11px] text-slate-600">Surge (&gt;₹850)</span>
              </div>
            </div>
          </div>
        </div>

        {/* Day Inspector Panel (1 Col on lg) */}
        <div className="bg-white rounded-2xl p-6 border border-slate-200 shadow-xs space-y-4 flex flex-col">
          <div>
            <h2 className="text-base font-bold text-slate-900">Day Details Inspector</h2>
            <p className="text-xs text-slate-500 mt-0.5">
              {inspectedDay
                ? `Breakdown for ${new Date(inspectedDay.date + 'T12:00:00').toLocaleDateString('en-US', {
                    weekday: 'long',
                    day: 'numeric',
                    month: 'long',
                    year: 'numeric',
                  })}`
                : 'Click any cell on the calendar to view its recorded student expenses.'}
            </p>
          </div>

          {inspectedDay ? (
            <div className="space-y-3 flex-1">
              {/* Day Summary Card */}
              <div className="p-4 rounded-xl bg-slate-50 border border-slate-200 flex items-center justify-between">
                <div>
                  <span className="text-[10px] uppercase font-bold text-slate-400 block">Total Outlay</span>
                  <span className="text-xl font-extrabold text-indigo-700 mt-0.5 block">
                    ₹{inspectedDay.amount.toLocaleString()}
                  </span>
                </div>
                <div className="text-right">
                  <span className="text-[10px] uppercase font-bold text-slate-400 block">Day Type</span>
                  <span className="text-xs font-bold text-slate-800 mt-0.5 block">
                    {inspectedDay.isWeekend ? 'Weekend 🏖️' : 'Weekday 🎓'}
                  </span>
                </div>
              </div>

              {/* Transaction List */}
              <div className="space-y-2">
                <span className="text-[11px] font-bold text-slate-500 uppercase tracking-wider block">
                  Logged Expenses ({inspectedExpenses.length})
                </span>

                {inspectedExpenses.length === 0 ? (
                  <div className="p-4 text-center text-xs text-slate-400 bg-slate-50 rounded-xl border border-dashed border-slate-200">
                    No transactions recorded on this day.
                  </div>
                ) : (
                  <div className="space-y-2 max-h-[320px] overflow-y-auto pr-1">
                    {inspectedExpenses.map((exp) => {
                      const meta = CATEGORIES[exp.category];
                      return (
                        <div
                          key={exp.id}
                          className="p-2.5 rounded-xl border border-slate-200 bg-white flex items-center justify-between"
                        >
                          <div className="flex items-center space-x-2.5 overflow-hidden">
                            <span className="text-lg shrink-0">{meta.emoji}</span>
                            <div className="truncate">
                              <span className="text-xs font-bold text-slate-800 block truncate">
                                {exp.description}
                              </span>
                              <span className="text-[10px] text-slate-500">
                                {exp.category} • {exp.paymentMethod}
                              </span>
                            </div>
                          </div>
                          <span className="text-xs font-extrabold text-slate-900 shrink-0 ml-2">
                            ₹{exp.amount.toLocaleString()}
                          </span>
                        </div>
                      );
                    })}
                  </div>
                )}
              </div>
            </div>
          ) : (
            <div className="p-8 text-center flex-1 flex flex-col items-center justify-center bg-slate-50 rounded-xl border border-dashed border-slate-200">
              <Info className="w-8 h-8 text-slate-400 mb-2" />
              <p className="text-xs font-bold text-slate-700">No Day Selected</p>
              <p className="text-[11px] text-slate-500 mt-1 max-w-[200px]">
                Click on any calendar day above to inspect individual expense records and category tags.
              </p>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
