import React, { useState, useMemo } from 'react';
import {
  Wallet,
  CheckCircle2,
  AlertTriangle,
  AlertOctagon,
  ShieldCheck,
  Edit2,
  RotateCcw,
  IndianRupee,
  Calendar,
  Sparkles,
} from 'lucide-react';
import { Budget, Expense, CategoryType } from '../types';
import { CATEGORIES, ALL_CATEGORIES } from '../data/categories';
import { computeBudgetProgress } from '../services/analyticsEngine';
import { DEFAULT_BUDGETS } from '../data/sampleData';

interface BudgetManagerProps {
  expenses: Expense[];
  budgets: Budget[];
  onUpdateBudgets: (newBudgets: Budget[]) => void;
}

export const BudgetManager: React.FC<BudgetManagerProps> = ({
  expenses,
  budgets,
  onUpdateBudgets,
}) => {
  const [editingCategory, setEditingCategory] = useState<CategoryType | null>(null);
  const [editLimit, setEditLimit] = useState<string>('');

  const currentMonthStr = '2026-09';
  const progressList = useMemo(() => {
    return computeBudgetProgress(expenses, budgets, currentMonthStr);
  }, [expenses, budgets, currentMonthStr]);

  const totalBudget = useMemo(() => budgets.reduce((sum, b) => sum + b.monthlyLimit, 0), [budgets]);
  const totalSpent = useMemo(() => progressList.reduce((sum, p) => sum + p.spent, 0), [progressList]);
  const totalRemaining = Math.max(0, totalBudget - totalSpent);
  const overallPercentage = totalBudget > 0 ? Math.round((totalSpent / totalBudget) * 100) : 0;

  // Days remaining in September 2026 (from Day 7 onwards = 23 days)
  const daysRemainingInMonth = 23;
  const recommendedDailyAllowance =
    totalRemaining > 0 ? Math.round(totalRemaining / daysRemainingInMonth) : 0;

  const handleStartEdit = (cat: CategoryType, currentLimit: number) => {
    setEditingCategory(cat);
    setEditLimit(currentLimit.toString());
  };

  const handleSaveEdit = (cat: CategoryType) => {
    const val = parseFloat(editLimit);
    if (isNaN(val) || val < 0) return;

    const updated = budgets.map((b) => (b.category === cat ? { ...b, monthlyLimit: val } : b));
    onUpdateBudgets(updated);
    setEditingCategory(null);
  };

  const handleResetDefaults = () => {
    if (window.confirm('Reset all category budgets to recommended college student defaults?')) {
      onUpdateBudgets(DEFAULT_BUDGETS);
    }
  };

  const getStatusBadge = (status: 'Safe' | 'Moderate' | 'Near Limit' | 'Exceeded') => {
    switch (status) {
      case 'Safe':
        return (
          <span className="px-2.5 py-0.5 rounded-full text-xs font-bold bg-emerald-100 text-emerald-800 border border-emerald-200 flex items-center gap-1">
            <ShieldCheck className="w-3.5 h-3.5 text-emerald-600" />
            Safe (&lt;60%)
          </span>
        );
      case 'Moderate':
        return (
          <span className="px-2.5 py-0.5 rounded-full text-xs font-bold bg-amber-100 text-amber-800 border border-amber-200 flex items-center gap-1">
            <CheckCircle2 className="w-3.5 h-3.5 text-amber-600" />
            Moderate (60-85%)
          </span>
        );
      case 'Near Limit':
        return (
          <span className="px-2.5 py-0.5 rounded-full text-xs font-bold bg-orange-100 text-orange-800 border border-orange-200 flex items-center gap-1 animate-pulse">
            <AlertTriangle className="w-3.5 h-3.5 text-orange-600" />
            Near Limit (85-100%)
          </span>
        );
      case 'Exceeded':
        return (
          <span className="px-2.5 py-0.5 rounded-full text-xs font-bold bg-rose-100 text-rose-800 border border-rose-200 flex items-center gap-1">
            <AlertOctagon className="w-3.5 h-3.5 text-rose-600" />
            Exceeded (&gt;100%)
          </span>
        );
    }
  };

  const getProgressBarColor = (status: 'Safe' | 'Moderate' | 'Near Limit' | 'Exceeded') => {
    switch (status) {
      case 'Safe':
        return 'bg-emerald-500';
      case 'Moderate':
        return 'bg-amber-500';
      case 'Near Limit':
        return 'bg-orange-500';
      case 'Exceeded':
        return 'bg-rose-500';
    }
  };

  return (
    <div className="space-y-6">
      {/* Overview Card */}
      <div className="bg-white rounded-2xl p-6 border border-slate-200 shadow-xs space-y-5">
        <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
          <div>
            <div className="flex items-center space-x-2">
              <span className="p-2 rounded-xl bg-indigo-50 text-indigo-600 border border-indigo-200">
                <Wallet className="w-5 h-5" />
              </span>
              <h1 className="text-2xl font-extrabold text-slate-900 tracking-tight">
                Monthly Budget Management
              </h1>
            </div>
            <p className="text-sm text-slate-600 mt-1">
              Set category limits, monitor spending velocity, and prevent month-end student cash crunches.
            </p>
          </div>

          <button
            onClick={handleResetDefaults}
            className="flex items-center space-x-1.5 px-3 py-1.5 rounded-lg border border-slate-300 text-slate-700 hover:bg-slate-50 text-xs font-semibold transition self-start sm:self-auto"
          >
            <RotateCcw className="w-3.5 h-3.5 text-slate-500" />
            <span>Reset Recommended Defaults</span>
          </button>
        </div>

        {/* Global Progress */}
        <div className="p-5 rounded-xl bg-gradient-to-r from-slate-50 to-indigo-50/40 border border-slate-200 space-y-3">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
            <div>
              <span className="text-xs font-bold uppercase text-slate-500">Total September Budget</span>
              <div className="flex items-baseline space-x-2 mt-0.5">
                <span className="text-2xl font-extrabold text-slate-900">
                  ₹{totalSpent.toLocaleString()}
                </span>
                <span className="text-sm font-semibold text-slate-500">
                  spent of ₹{totalBudget.toLocaleString()} limit
                </span>
              </div>
            </div>

            <div className="text-left sm:text-right">
              <span className="text-xs font-bold uppercase text-slate-500">Daily Recommended Spend</span>
              <div className="text-lg font-extrabold text-emerald-700 mt-0.5">
                ₹{recommendedDailyAllowance.toLocaleString()} / day
              </div>
              <span className="text-[11px] text-slate-500">for next {daysRemainingInMonth} days</span>
            </div>
          </div>

          {/* Bar */}
          <div className="space-y-1">
            <div className="w-full h-3.5 rounded-full bg-slate-200 overflow-hidden">
              <div
                className={`h-full rounded-full transition-all duration-500 ${
                  overallPercentage > 100
                    ? 'bg-rose-500'
                    : overallPercentage > 85
                    ? 'bg-orange-500'
                    : overallPercentage > 60
                    ? 'bg-amber-500'
                    : 'bg-indigo-600'
                }`}
                style={{ width: `${Math.min(100, overallPercentage)}%` }}
              />
            </div>
            <div className="flex items-center justify-between text-xs text-slate-600 font-semibold pt-1">
              <span>{overallPercentage}% Utilized</span>
              <span>₹{totalRemaining.toLocaleString()} remaining in total reserve</span>
            </div>
          </div>
        </div>
      </div>

      {/* Category Budgets Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {progressList.map((item) => {
          const meta = CATEGORIES[item.category];
          const isEditing = editingCategory === item.category;

          return (
            <div
              key={item.category}
              className="bg-white rounded-2xl p-5 border border-slate-200 shadow-xs space-y-4 hover:border-slate-300 transition"
            >
              {/* Category Header */}
              <div className="flex items-center justify-between">
                <div className="flex items-center space-x-3">
                  <div
                    className="w-10 h-10 rounded-xl flex items-center justify-center text-xl"
                    style={{ backgroundColor: meta.color + '15', border: `1px solid ${meta.color}40` }}
                  >
                    {meta.emoji}
                  </div>
                  <div>
                    <h3 className="text-sm font-bold text-slate-900">{meta.label}</h3>
                    <span className="text-[11px] text-slate-500">{item.category} budget</span>
                  </div>
                </div>

                {getStatusBadge(item.status)}
              </div>

              {/* Amount Figures */}
              <div className="flex items-end justify-between pt-1">
                <div>
                  <span className="text-[10px] uppercase font-bold text-slate-400 block">Spent Amount</span>
                  <span className="text-lg font-extrabold text-slate-900 mt-0.5 block">
                    ₹{item.spent.toLocaleString()}
                  </span>
                </div>

                {isEditing ? (
                  <div className="flex items-center space-x-1.5">
                    <input
                      type="number"
                      value={editLimit}
                      onChange={(e) => setEditLimit(e.target.value)}
                      className="w-24 px-2 py-1 bg-slate-50 border border-slate-300 rounded-lg text-xs font-bold text-slate-900 focus:outline-none focus:ring-2 focus:ring-indigo-500"
                      autoFocus
                    />
                    <button
                      onClick={() => handleSaveEdit(item.category)}
                      className="px-2 py-1 bg-indigo-600 text-white rounded-lg text-xs font-bold"
                    >
                      Save
                    </button>
                    <button
                      onClick={() => setEditingCategory(null)}
                      className="px-2 py-1 text-slate-500 text-xs"
                    >
                      Cancel
                    </button>
                  </div>
                ) : (
                  <div className="text-right flex items-center space-x-2">
                    <div>
                      <span className="text-[10px] uppercase font-bold text-slate-400 block">Monthly Limit</span>
                      <span className="text-xs font-bold text-slate-700 block">
                        ₹{item.monthlyLimit.toLocaleString()}
                      </span>
                    </div>
                    <button
                      type="button"
                      onClick={() => handleStartEdit(item.category, item.monthlyLimit)}
                      className="p-1 rounded-md text-slate-400 hover:text-indigo-600 hover:bg-indigo-50 transition"
                      title="Edit Category Budget"
                    >
                      <Edit2 className="w-3.5 h-3.5" />
                    </button>
                  </div>
                )}
              </div>

              {/* Progress Bar */}
              <div className="space-y-1.5">
                <div className="w-full h-2.5 rounded-full bg-slate-100 overflow-hidden">
                  <div
                    className={`h-full rounded-full transition-all duration-500 ${getProgressBarColor(
                      item.status
                    )}`}
                    style={{ width: `${Math.min(100, item.percentageUsed)}%` }}
                  />
                </div>

                <div className="flex items-center justify-between text-[11px] text-slate-500 font-semibold">
                  <span>{item.percentageUsed}% used</span>
                  <span>
                    {item.spent > item.monthlyLimit ? (
                      <span className="text-rose-600 font-bold">
                        ₹{(item.spent - item.monthlyLimit).toLocaleString()} over budget
                      </span>
                    ) : (
                      <span className="text-emerald-700">
                        ₹{item.remaining.toLocaleString()} left
                      </span>
                    )}
                  </span>
                </div>
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
};
