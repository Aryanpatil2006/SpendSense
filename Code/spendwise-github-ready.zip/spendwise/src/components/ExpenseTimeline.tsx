import React, { useState, useMemo } from 'react';
import {
  Search,
  Filter,
  ArrowUpDown,
  Trash2,
  Edit2,
  Calendar,
  IndianRupee,
  CreditCard,
  Tag,
  AlertCircle,
  FileDown,
  Clock,
} from 'lucide-react';
import { Expense, CategoryType, PaymentMethod } from '../types';
import { CATEGORIES, ALL_CATEGORIES } from '../data/categories';
import { exportExpensesToCSV, downloadCSV } from '../services/storage';

interface ExpenseTimelineProps {
  expenses: Expense[];
  onEditExpense: (expense: Expense) => void;
  onDeleteExpense: (id: string) => void;
  onAddNewClick: () => void;
}

export const ExpenseTimeline: React.FC<ExpenseTimelineProps> = ({
  expenses,
  onEditExpense,
  onDeleteExpense,
  onAddNewClick,
}) => {
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedCategory, setSelectedCategory] = useState<string>('all');
  const [selectedPaymentMethod, setSelectedPaymentMethod] = useState<string>('all');
  const [sortBy, setSortBy] = useState<'newest' | 'oldest' | 'highest' | 'lowest'>('newest');
  const [dateFilter, setDateFilter] = useState<string>('all'); // 'all', 'sep2026', 'aug2026', 'today'
  const [minAmount, setMinAmount] = useState<string>('');
  const [maxAmount, setMaxAmount] = useState<string>('');

  const [confirmDeleteId, setConfirmDeleteId] = useState<string | null>(null);

  // Filter & sort logic
  const filteredExpenses = useMemo(() => {
    return expenses
      .filter((exp) => {
        // Search description & note
        if (searchTerm.trim()) {
          const s = searchTerm.toLowerCase();
          const matchDesc = exp.description.toLowerCase().includes(s);
          const matchNote = exp.note ? exp.note.toLowerCase().includes(s) : false;
          const matchCat = exp.category.toLowerCase().includes(s);
          if (!matchDesc && !matchNote && !matchCat) return false;
        }

        // Category
        if (selectedCategory !== 'all' && exp.category !== selectedCategory) {
          return false;
        }

        // Payment Method
        if (selectedPaymentMethod !== 'all' && exp.paymentMethod !== selectedPaymentMethod) {
          return false;
        }

        // Date Presets
        if (dateFilter === 'today' && exp.date !== '2026-09-07') {
          return false;
        }
        if (dateFilter === 'sep2026' && !exp.date.startsWith('2026-09')) {
          return false;
        }
        if (dateFilter === 'aug2026' && !exp.date.startsWith('2026-08')) {
          return false;
        }

        // Min / Max amount
        if (minAmount && exp.amount < parseFloat(minAmount)) {
          return false;
        }
        if (maxAmount && exp.amount > parseFloat(maxAmount)) {
          return false;
        }

        return true;
      })
      .sort((a, b) => {
        if (sortBy === 'newest') {
          return b.date.localeCompare(a.date) || b.createdAt - a.createdAt;
        }
        if (sortBy === 'oldest') {
          return a.date.localeCompare(b.date) || a.createdAt - b.createdAt;
        }
        if (sortBy === 'highest') {
          return b.amount - a.amount;
        }
        if (sortBy === 'lowest') {
          return a.amount - b.amount;
        }
        return 0;
      });
  }, [
    expenses,
    searchTerm,
    selectedCategory,
    selectedPaymentMethod,
    sortBy,
    dateFilter,
    minAmount,
    maxAmount,
  ]);

  // Group by date for chronological timeline view
  const groupedByDate = useMemo(() => {
    const groups: { date: string; formattedDate: string; items: Expense[]; dayTotal: number }[] = [];
    const dateMap = new Map<string, Expense[]>();

    for (const item of filteredExpenses) {
      if (!dateMap.has(item.date)) {
        dateMap.set(item.date, []);
      }
      dateMap.get(item.date)!.push(item);
    }

    dateMap.forEach((items, dateStr) => {
      const d = new Date(dateStr + 'T12:00:00');
      const formattedDate = d.toLocaleDateString('en-US', {
        day: '2-digit',
        month: 'long',
        year: 'numeric',
      });
      const dayTotal = items.reduce((sum, e) => sum + e.amount, 0);
      groups.push({ date: dateStr, formattedDate, items, dayTotal });
    });

    return groups;
  }, [filteredExpenses]);

  const totalFilteredAmount = useMemo(
    () => filteredExpenses.reduce((sum, e) => sum + e.amount, 0),
    [filteredExpenses]
  );

  const handleExportFiltered = () => {
    const csv = exportExpensesToCSV(filteredExpenses);
    downloadCSV(csv, `spendwise_filtered_logs_${Date.now()}.csv`);
  };

  const resetFilters = () => {
    setSearchTerm('');
    setSelectedCategory('all');
    setSelectedPaymentMethod('all');
    setSortBy('newest');
    setDateFilter('all');
    setMinAmount('');
    setMaxAmount('');
  };

  return (
    <div className="space-y-6">
      {/* Header & Controls */}
      <div className="bg-white rounded-2xl p-6 border border-slate-200 shadow-xs space-y-4">
        <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
          <div>
            <h1 className="text-2xl font-extrabold text-slate-900 tracking-tight flex items-center gap-2">
              <Clock className="w-6 h-6 text-indigo-600" />
              <span>Expense Timeline & Visual Logs</span>
            </h1>
            <p className="text-sm text-slate-600 mt-0.5">
              Chronological ledger with multi-criteria search, filters, day totals, and instant updates.
            </p>
          </div>

          <div className="flex items-center space-x-2">
            <button
              onClick={handleExportFiltered}
              className="px-3 py-1.5 rounded-lg border border-slate-300 text-slate-700 hover:bg-slate-50 text-xs font-semibold flex items-center space-x-1.5 transition"
            >
              <FileDown className="w-3.5 h-3.5 text-slate-500" />
              <span>Export CSV</span>
            </button>
            <button
              onClick={onAddNewClick}
              className="px-3.5 py-1.5 rounded-lg bg-indigo-600 hover:bg-indigo-700 text-white text-xs font-bold transition shadow-xs"
            >
              + Log Expense
            </button>
          </div>
        </div>

        {/* Search & Filter Bar */}
        <div className="grid grid-cols-1 md:grid-cols-12 gap-3 pt-2">
          {/* Search box */}
          <div className="md:col-span-4 relative">
            <Search className="w-4 h-4 text-slate-400 absolute left-3 top-3" />
            <input
              type="text"
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              placeholder="Search description, notes, category..."
              className="w-full pl-9 pr-4 py-2 bg-slate-50 border border-slate-300 rounded-xl text-xs font-medium focus:bg-white focus:outline-none focus:ring-2 focus:ring-indigo-500"
            />
          </div>

          {/* Category Filter */}
          <div className="md:col-span-2">
            <select
              value={selectedCategory}
              onChange={(e) => setSelectedCategory(e.target.value)}
              className="w-full px-3 py-2 bg-slate-50 border border-slate-300 rounded-xl text-xs font-medium focus:bg-white focus:outline-none focus:ring-2 focus:ring-indigo-500"
            >
              <option value="all">All Categories</option>
              {ALL_CATEGORIES.map((cat) => (
                <option key={cat} value={cat}>
                  {CATEGORIES[cat].emoji} {cat}
                </option>
              ))}
            </select>
          </div>

          {/* Date Filter */}
          <div className="md:col-span-2">
            <select
              value={dateFilter}
              onChange={(e) => setDateFilter(e.target.value)}
              className="w-full px-3 py-2 bg-slate-50 border border-slate-300 rounded-xl text-xs font-medium focus:bg-white focus:outline-none focus:ring-2 focus:ring-indigo-500"
            >
              <option value="all">All Dates</option>
              <option value="today">Today (Sep 7)</option>
              <option value="sep2026">September 2026</option>
              <option value="aug2026">August 2026</option>
            </select>
          </div>

          {/* Payment Method */}
          <div className="md:col-span-2">
            <select
              value={selectedPaymentMethod}
              onChange={(e) => setSelectedPaymentMethod(e.target.value)}
              className="w-full px-3 py-2 bg-slate-50 border border-slate-300 rounded-xl text-xs font-medium focus:bg-white focus:outline-none focus:ring-2 focus:ring-indigo-500"
            >
              <option value="all">All Payments</option>
              <option value="UPI">UPI</option>
              <option value="Cash">Cash</option>
              <option value="Debit Card">Debit Card</option>
              <option value="Credit Card">Credit Card</option>
              <option value="Net Banking">Net Banking</option>
            </select>
          </div>

          {/* Sort By */}
          <div className="md:col-span-2">
            <select
              value={sortBy}
              onChange={(e) => setSortBy(e.target.value as any)}
              className="w-full px-3 py-2 bg-slate-50 border border-slate-300 rounded-xl text-xs font-medium focus:bg-white focus:outline-none focus:ring-2 focus:ring-indigo-500"
            >
              <option value="newest">Newest First</option>
              <option value="oldest">Oldest First</option>
              <option value="highest">Highest Amount</option>
              <option value="lowest">Lowest Amount</option>
            </select>
          </div>
        </div>

        {/* Filter summary bar */}
        <div className="flex flex-wrap items-center justify-between text-xs text-slate-500 pt-2 border-t border-slate-100">
          <div>
            Showing <strong className="text-slate-800">{filteredExpenses.length}</strong> of{' '}
            <strong className="text-slate-800">{expenses.length}</strong> records • Total Filtered:{' '}
            <strong className="text-indigo-600 font-bold">₹{totalFilteredAmount.toLocaleString()}</strong>
          </div>

          {(searchTerm ||
            selectedCategory !== 'all' ||
            selectedPaymentMethod !== 'all' ||
            dateFilter !== 'all' ||
            minAmount ||
            maxAmount) && (
            <button
              onClick={resetFilters}
              className="text-indigo-600 hover:text-indigo-800 font-bold transition"
            >
              Clear all filters
            </button>
          )}
        </div>
      </div>

      {/* Visual Chronological Timeline */}
      {groupedByDate.length === 0 ? (
        <div className="bg-white rounded-2xl p-12 text-center border border-slate-200 shadow-xs">
          <AlertCircle className="w-12 h-12 text-slate-300 mx-auto mb-3" />
          <h3 className="text-base font-bold text-slate-800">No matching expense records</h3>
          <p className="text-xs text-slate-500 mt-1 max-w-sm mx-auto">
            Try adjusting your search criteria, reset active filters, or log a new student expense.
          </p>
          <button
            onClick={resetFilters}
            className="mt-4 px-4 py-2 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-700 text-xs font-bold transition"
          >
            Reset Filters
          </button>
        </div>
      ) : (
        <div className="space-y-6">
          {groupedByDate.map((group) => (
            <div key={group.date} className="space-y-3">
              {/* Date Group Header Banner */}
              <div className="flex items-center justify-between px-4 py-2 bg-slate-100/80 rounded-xl border border-slate-200">
                <div className="flex items-center space-x-2">
                  <Calendar className="w-4 h-4 text-indigo-600" />
                  <span className="text-xs font-extrabold text-slate-800 tracking-tight">
                    {group.formattedDate}
                  </span>
                  <span className="text-[10px] px-2 py-0.5 rounded-md bg-white text-slate-600 font-semibold border border-slate-200">
                    {group.items.length} {group.items.length === 1 ? 'transaction' : 'transactions'}
                  </span>
                </div>
                <div className="text-xs font-extrabold text-slate-900">
                  Day Total: <span className="text-indigo-700">₹{group.dayTotal.toLocaleString()}</span>
                </div>
              </div>

              {/* Items in this Day */}
              <div className="space-y-2.5 pl-2 sm:pl-4 border-l-2 border-indigo-200">
                {group.items.map((exp) => {
                  const meta = CATEGORIES[exp.category];
                  return (
                    <div
                      key={exp.id}
                      className="bg-white rounded-xl p-4 border border-slate-200 shadow-xs hover:border-slate-300 transition flex flex-col sm:flex-row sm:items-center sm:justify-between gap-3"
                    >
                      {/* Left: Icon & Description */}
                      <div className="flex items-start space-x-3">
                        <div
                          className="w-10 h-10 rounded-xl flex items-center justify-center text-xl shrink-0"
                          style={{ backgroundColor: meta.color + '15', border: `1px solid ${meta.color}40` }}
                        >
                          {meta.emoji}
                        </div>

                        <div>
                          <div className="flex items-center space-x-2">
                            <span className="text-sm font-bold text-slate-900">{exp.description}</span>
                            <span
                              className="text-[10px] font-bold px-2 py-0.5 rounded-full"
                              style={{
                                backgroundColor: meta.color + '15',
                                color: meta.color,
                              }}
                            >
                              {exp.category}
                            </span>
                          </div>

                          <div className="flex flex-wrap items-center gap-2 mt-1 text-[11px] text-slate-500">
                            <span className="flex items-center gap-1 font-medium bg-slate-50 px-2 py-0.5 rounded-md border border-slate-200">
                              <CreditCard className="w-3 h-3 text-slate-400" />
                              {exp.paymentMethod}
                            </span>
                            {exp.note && (
                              <span className="italic text-slate-600">"{exp.note}"</span>
                            )}
                          </div>
                        </div>
                      </div>

                      {/* Right: Amount & Actions */}
                      <div className="flex items-center justify-between sm:justify-end space-x-4 pt-2 sm:pt-0 border-t sm:border-t-0 border-slate-100">
                        <div className="text-right">
                          <span className="text-base font-extrabold text-slate-900 block">
                            ₹{exp.amount.toLocaleString()}
                          </span>
                        </div>

                        {/* Action buttons */}
                        <div className="flex items-center space-x-1">
                          <button
                            type="button"
                            onClick={() => onEditExpense(exp)}
                            className="p-1.5 rounded-lg text-slate-400 hover:text-indigo-600 hover:bg-indigo-50 transition"
                            title="Edit this expense"
                          >
                            <Edit2 className="w-3.5 h-3.5" />
                          </button>

                          {confirmDeleteId === exp.id ? (
                            <div className="flex items-center space-x-1 bg-rose-50 p-1 rounded-lg border border-rose-200">
                              <span className="text-[10px] text-rose-700 font-bold px-1">Delete?</span>
                              <button
                                onClick={() => {
                                  onDeleteExpense(exp.id);
                                  setConfirmDeleteId(null);
                                }}
                                className="px-2 py-0.5 bg-rose-600 text-white rounded text-[10px] font-bold"
                              >
                                Yes
                              </button>
                              <button
                                onClick={() => setConfirmDeleteId(null)}
                                className="px-1.5 py-0.5 text-slate-600 text-[10px]"
                              >
                                No
                              </button>
                            </div>
                          ) : (
                            <button
                              type="button"
                              onClick={() => setConfirmDeleteId(exp.id)}
                              className="p-1.5 rounded-lg text-slate-400 hover:text-rose-600 hover:bg-rose-50 transition"
                              title="Delete this record"
                            >
                              <Trash2 className="w-3.5 h-3.5" />
                            </button>
                          )}
                        </div>
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
};
