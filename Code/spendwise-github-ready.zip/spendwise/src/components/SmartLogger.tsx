import React, { useState, useEffect } from 'react';
import {
  Sparkles,
  Edit3,
  Calendar,
  IndianRupee,
  Tag,
  CreditCard,
  FileText,
  CheckCircle2,
  AlertCircle,
  Zap,
} from 'lucide-react';
import { Expense, CategoryType, PaymentMethod } from '../types';
import { CATEGORIES, ALL_CATEGORIES } from '../data/categories';
import { parseNaturalExpense } from '../services/expenseParser';

interface SmartLoggerProps {
  onAddExpense: (expense: Omit<Expense, 'id' | 'createdAt'>) => void;
  referenceDate?: string;
  onSuccessNavigate?: () => void;
}

export const SmartLogger: React.FC<SmartLoggerProps> = ({
  onAddExpense,
  referenceDate = '2026-09-07',
  onSuccessNavigate,
}) => {
  const [activeMode, setActiveMode] = useState<'natural' | 'manual'>('natural');

  // Natural language state
  const [naturalInput, setNaturalInput] = useState('');
  const [parsed, setParsed] = useState(parseNaturalExpense('', referenceDate));

  // Manual structured state
  const [manualAmount, setManualAmount] = useState('');
  const [manualDescription, setManualDescription] = useState('');
  const [manualCategory, setManualCategory] = useState<CategoryType>('Food');
  const [manualDate, setManualDate] = useState(referenceDate);
  const [manualPaymentMethod, setManualPaymentMethod] = useState<PaymentMethod>('UPI');
  const [manualNote, setManualNote] = useState('');

  const [validationError, setValidationError] = useState<string | null>(null);
  const [successMessage, setSuccessMessage] = useState<string | null>(null);

  // Update parsed result whenever natural input changes
  useEffect(() => {
    if (naturalInput.trim()) {
      setParsed(parseNaturalExpense(naturalInput, referenceDate));
    } else {
      setParsed(parseNaturalExpense('', referenceDate));
    }
  }, [naturalInput, referenceDate]);

  // Auto-suggest category in manual mode when description changes
  const handleDescriptionChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const val = e.target.value;
    setManualDescription(val);
    if (val.length > 2) {
      const auto = parseNaturalExpense(val, referenceDate);
      if (auto.category !== 'Other') {
        setManualCategory(auto.category);
      }
    }
  };

  const handleNaturalSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setValidationError(null);

    if (!parsed.amount || parsed.amount <= 0) {
      setValidationError('Please include a valid expense amount (e.g., ₹150 lunch).');
      return;
    }
    if (!parsed.description.trim()) {
      setValidationError('Please include a brief description of what this expense was for.');
      return;
    }

    onAddExpense({
      amount: parsed.amount,
      description: parsed.description,
      category: parsed.category,
      date: parsed.date || referenceDate,
      paymentMethod: parsed.paymentMethod,
      note: `Parsed from: "${parsed.rawText}"`,
    });

    setSuccessMessage(`Logged ₹${parsed.amount} for "${parsed.description}" under ${parsed.category}!`);
    setNaturalInput('');
    setTimeout(() => {
      setSuccessMessage(null);
      if (onSuccessNavigate) onSuccessNavigate();
    }, 1200);
  };

  const handleManualSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setValidationError(null);

    const amountNum = parseFloat(manualAmount);
    if (isNaN(amountNum) || amountNum <= 0) {
      setValidationError('Amount must be a positive number greater than 0.');
      return;
    }
    if (!manualDescription.trim()) {
      setValidationError('Description is required (e.g. Canteen lunch, Bus pass).');
      return;
    }
    if (!manualDate) {
      setValidationError('Please select a valid date.');
      return;
    }

    onAddExpense({
      amount: amountNum,
      description: manualDescription.trim(),
      category: manualCategory,
      date: manualDate,
      paymentMethod: manualPaymentMethod,
      note: manualNote.trim() || undefined,
    });

    setSuccessMessage(`Saved ₹${amountNum} for "${manualDescription.trim()}"!`);
    setManualAmount('');
    setManualDescription('');
    setManualNote('');
    setTimeout(() => {
      setSuccessMessage(null);
      if (onSuccessNavigate) onSuccessNavigate();
    }, 1200);
  };

  const quickChips = [
    '₹120 lunch at college',
    '40 bus ticket',
    '250 notebook and xerox lab manuals',
    'Netflix 199 subscription',
    '85 paracetamol and cough syrup',
    '850 new backpack on amazon',
    '60 evening tea and samosa',
  ];

  return (
    <div className="max-w-4xl mx-auto space-y-6">
      {/* Header */}
      <div className="bg-white rounded-2xl p-6 border border-slate-200 shadow-xs">
        <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
          <div>
            <h1 className="text-2xl font-extrabold text-slate-900 tracking-tight flex items-center gap-2">
              <Sparkles className="w-6 h-6 text-indigo-600" />
              <span>Smart Expense Logger</span>
            </h1>
            <p className="text-sm text-slate-600 mt-1">
              Natural language parser extracts amounts, categories, and payment methods in real-time.
            </p>
          </div>

          {/* Mode Switcher */}
          <div className="inline-flex p-1 rounded-xl bg-slate-100 border border-slate-200 self-start sm:self-auto">
            <button
              type="button"
              onClick={() => {
                setActiveMode('natural');
                setValidationError(null);
              }}
              className={`flex items-center space-x-2 px-4 py-2 rounded-lg text-xs font-bold transition ${
                activeMode === 'natural'
                  ? 'bg-white text-indigo-700 shadow-xs'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              <Zap className="w-3.5 h-3.5 text-indigo-500" />
              <span>Natural Log (Quick)</span>
            </button>
            <button
              type="button"
              onClick={() => {
                setActiveMode('manual');
                setValidationError(null);
              }}
              className={`flex items-center space-x-2 px-4 py-2 rounded-lg text-xs font-bold transition ${
                activeMode === 'manual'
                  ? 'bg-white text-indigo-700 shadow-xs'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              <Edit3 className="w-3.5 h-3.5 text-indigo-500" />
              <span>Structured Form</span>
            </button>
          </div>
        </div>

        {/* Notifications */}
        {validationError && (
          <div className="mt-4 p-3 rounded-xl bg-rose-50 border border-rose-200 text-rose-800 text-xs font-semibold flex items-center space-x-2 animate-fade-in">
            <AlertCircle className="w-4 h-4 text-rose-500 shrink-0" />
            <span>{validationError}</span>
          </div>
        )}

        {successMessage && (
          <div className="mt-4 p-3 rounded-xl bg-emerald-50 border border-emerald-200 text-emerald-800 text-xs font-bold flex items-center space-x-2 animate-fade-in">
            <CheckCircle2 className="w-4 h-4 text-emerald-500 shrink-0" />
            <span>{successMessage}</span>
          </div>
        )}
      </div>

      {/* Mode 1: Natural Language Logger */}
      {activeMode === 'natural' && (
        <div className="bg-white rounded-2xl p-6 border border-slate-200 shadow-xs space-y-6">
          <form onSubmit={handleNaturalSubmit} className="space-y-4">
            <div>
              <label className="block text-xs font-bold uppercase tracking-wider text-slate-500 mb-2">
                Type Naturally (amount, description, context)
              </label>
              <div className="relative">
                <input
                  type="text"
                  value={naturalInput}
                  onChange={(e) => setNaturalInput(e.target.value)}
                  placeholder="e.g. ₹150 lunch with friends at college canteen..."
                  className="w-full pl-4 pr-12 py-3.5 bg-slate-50 border border-slate-300 rounded-xl text-slate-900 text-sm focus:bg-white focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500 transition font-medium"
                  autoFocus
                />
                <button
                  type="submit"
                  disabled={!parsed.amount}
                  className={`absolute right-2 top-2 px-4 py-2 rounded-lg text-xs font-bold text-white transition ${
                    parsed.amount
                      ? 'bg-indigo-600 hover:bg-indigo-700 shadow-xs cursor-pointer'
                      : 'bg-slate-300 cursor-not-allowed'
                  }`}
                >
                  Log
                </button>
              </div>
            </div>

            {/* Quick Chips */}
            <div>
              <p className="text-[11px] font-semibold text-slate-500 mb-2">Sample Student Logs to try:</p>
              <div className="flex flex-wrap gap-2">
                {quickChips.map((chip, idx) => (
                  <button
                    key={idx}
                    type="button"
                    onClick={() => setNaturalInput(chip)}
                    className="px-2.5 py-1 rounded-lg bg-slate-100 hover:bg-indigo-50 hover:text-indigo-700 border border-slate-200 text-slate-700 text-xs font-medium transition cursor-pointer"
                  >
                    {chip}
                  </button>
                ))}
              </div>
            </div>
          </form>

          {/* Live Extraction Preview Card */}
          <div className="p-5 rounded-xl bg-gradient-to-r from-slate-50 to-indigo-50/40 border border-slate-200">
            <div className="flex items-center justify-between mb-3">
              <span className="text-xs font-bold text-slate-700 uppercase tracking-wider flex items-center gap-1.5">
                <Zap className="w-3.5 h-3.5 text-indigo-600" />
                Live Rule-Based Parser Output
              </span>
              {parsed.confidence > 0 && (
                <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-indigo-100 text-indigo-800 border border-indigo-200">
                  Confidence: {parsed.confidence}%
                </span>
              )}
            </div>

            <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
              <div className="p-3 bg-white rounded-lg border border-slate-200">
                <span className="text-[10px] uppercase font-bold text-slate-400 block">Extracted Amount</span>
                <span className="text-base font-extrabold text-slate-900 mt-0.5 block">
                  {parsed.amount ? `₹${parsed.amount.toLocaleString()}` : '—'}
                </span>
              </div>

              <div className="p-3 bg-white rounded-lg border border-slate-200">
                <span className="text-[10px] uppercase font-bold text-slate-400 block">Auto Category</span>
                <div className="flex items-center space-x-1.5 mt-0.5">
                  <span className="text-base">{CATEGORIES[parsed.category]?.emoji}</span>
                  <span className="text-xs font-bold text-slate-800">{parsed.category}</span>
                </div>
              </div>

              <div className="p-3 bg-white rounded-lg border border-slate-200">
                <span className="text-[10px] uppercase font-bold text-slate-400 block">Payment Mode</span>
                <span className="text-xs font-bold text-slate-800 mt-1 block">{parsed.paymentMethod}</span>
              </div>

              <div className="p-3 bg-white rounded-lg border border-slate-200">
                <span className="text-[10px] uppercase font-bold text-slate-400 block">Target Date</span>
                <span className="text-xs font-bold text-slate-800 mt-1 block">{parsed.date}</span>
              </div>
            </div>

            <div className="mt-3 p-3 bg-white rounded-lg border border-slate-200">
              <span className="text-[10px] uppercase font-bold text-slate-400 block">Cleaned Description</span>
              <p className="text-xs font-semibold text-slate-800 mt-0.5">
                {parsed.description || 'Waiting for input...'}
              </p>
            </div>
          </div>
        </div>
      )}

      {/* Mode 2: Structured Manual Entry */}
      {activeMode === 'manual' && (
        <form
          onSubmit={handleManualSubmit}
          className="bg-white rounded-2xl p-6 border border-slate-200 shadow-xs space-y-5"
        >
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-5">
            {/* Amount */}
            <div>
              <label className="block text-xs font-bold uppercase tracking-wider text-slate-600 mb-1.5 flex items-center gap-1.5">
                <IndianRupee className="w-3.5 h-3.5 text-indigo-600" />
                Amount (INR ₹) *
              </label>
              <input
                type="number"
                step="0.01"
                min="0.01"
                required
                value={manualAmount}
                onChange={(e) => setManualAmount(e.target.value)}
                placeholder="150"
                className="w-full px-4 py-2.5 bg-slate-50 border border-slate-300 rounded-xl text-slate-900 text-sm font-semibold focus:bg-white focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500 transition"
              />
            </div>

            {/* Date */}
            <div>
              <label className="block text-xs font-bold uppercase tracking-wider text-slate-600 mb-1.5 flex items-center gap-1.5">
                <Calendar className="w-3.5 h-3.5 text-indigo-600" />
                Date of Expense *
              </label>
              <input
                type="date"
                required
                value={manualDate}
                onChange={(e) => setManualDate(e.target.value)}
                className="w-full px-4 py-2.5 bg-slate-50 border border-slate-300 rounded-xl text-slate-900 text-sm font-semibold focus:bg-white focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500 transition"
              />
            </div>
          </div>

          {/* Description */}
          <div>
            <label className="block text-xs font-bold uppercase tracking-wider text-slate-600 mb-1.5 flex items-center gap-1.5">
              <FileText className="w-3.5 h-3.5 text-indigo-600" />
              Description / Item Name *
            </label>
            <input
              type="text"
              required
              value={manualDescription}
              onChange={handleDescriptionChange}
              placeholder="e.g. Canteen lunch, bus return ticket, photocopy assignment"
              className="w-full px-4 py-2.5 bg-slate-50 border border-slate-300 rounded-xl text-slate-900 text-sm font-medium focus:bg-white focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500 transition"
            />
          </div>

          {/* Category Selector Grid */}
          <div>
            <label className="block text-xs font-bold uppercase tracking-wider text-slate-600 mb-2 flex items-center gap-1.5">
              <Tag className="w-3.5 h-3.5 text-indigo-600" />
              Category (Auto-detected or select manually)
            </label>
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-2.5">
              {ALL_CATEGORIES.map((cat) => {
                const meta = CATEGORIES[cat];
                const isSelected = manualCategory === cat;
                return (
                  <button
                    key={cat}
                    type="button"
                    onClick={() => setManualCategory(cat)}
                    className={`p-2.5 rounded-xl border text-left transition flex items-center space-x-2.5 cursor-pointer ${
                      isSelected
                        ? 'bg-indigo-50 border-indigo-600 text-indigo-900 ring-2 ring-indigo-500/20 shadow-xs'
                        : 'bg-white border-slate-200 text-slate-700 hover:bg-slate-50'
                    }`}
                  >
                    <span className="text-xl">{meta.emoji}</span>
                    <div className="overflow-hidden">
                      <span className="text-xs font-bold block truncate">{cat}</span>
                    </div>
                  </button>
                );
              })}
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-5">
            {/* Payment Method */}
            <div>
              <label className="block text-xs font-bold uppercase tracking-wider text-slate-600 mb-1.5 flex items-center gap-1.5">
                <CreditCard className="w-3.5 h-3.5 text-indigo-600" />
                Payment Method
              </label>
              <select
                value={manualPaymentMethod}
                onChange={(e) => setManualPaymentMethod(e.target.value as PaymentMethod)}
                className="w-full px-4 py-2.5 bg-slate-50 border border-slate-300 rounded-xl text-slate-900 text-sm font-medium focus:bg-white focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500 transition"
              >
                <option value="UPI">UPI (Google Pay / PhonePe / Paytm)</option>
                <option value="Cash">Cash</option>
                <option value="Debit Card">Debit Card</option>
                <option value="Credit Card">Credit Card</option>
                <option value="Net Banking">Net Banking</option>
              </select>
            </div>

            {/* Optional Note */}
            <div>
              <label className="block text-xs font-bold uppercase tracking-wider text-slate-600 mb-1.5">
                Optional Note / Tag
              </label>
              <input
                type="text"
                value={manualNote}
                onChange={(e) => setManualNote(e.target.value)}
                placeholder="e.g. Split with Rahul, semester lab project"
                className="w-full px-4 py-2.5 bg-slate-50 border border-slate-300 rounded-xl text-slate-900 text-sm font-medium focus:bg-white focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500 transition"
              />
            </div>
          </div>

          {/* Submit */}
          <div className="pt-3 border-t border-slate-100 flex justify-end">
            <button
              type="submit"
              className="px-6 py-2.5 rounded-xl bg-indigo-600 hover:bg-indigo-700 text-white text-xs font-bold shadow-md shadow-indigo-100 transition cursor-pointer"
            >
              Save Expense Record
            </button>
          </div>
        </form>
      )}
    </div>
  );
};
