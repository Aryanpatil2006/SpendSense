import React from 'react';
import {
  LayoutDashboard,
  PlusCircle,
  Clock,
  Sparkles,
  Calendar,
  Wallet,
  FileSpreadsheet,
  RotateCcw,
  Trash2,
  CheckCircle2,
} from 'lucide-react';

export type ActiveTab =
  | 'dashboard'
  | 'logger'
  | 'logs'
  | 'analytics'
  | 'heatmap'
  | 'budgets'
  | 'reports';

interface NavbarProps {
  activeTab: ActiveTab;
  setActiveTab: (tab: ActiveTab) => void;
  onResetSample?: () => void;
  onResetData?: () => void;
  onClearAll: () => void;
  expenseCount?: number;
  totalCount?: number;
}

export const Navbar: React.FC<NavbarProps> = ({
  activeTab,
  setActiveTab,
  onResetSample,
  onResetData,
  onClearAll,
  expenseCount,
  totalCount,
}) => {
  const [showMenu, setShowMenu] = React.useState(false);
  const count = expenseCount ?? totalCount ?? 0;
  const handleReset = onResetSample ?? onResetData ?? (() => {});

  const navItems = [
    { id: 'dashboard', label: 'Dashboard', icon: LayoutDashboard },
    { id: 'logger', label: 'Add Expense', icon: PlusCircle },
    { id: 'logs', label: 'Visual Logs', icon: Clock, badge: count },
    { id: 'analytics', label: 'Analytics & Personality', icon: Sparkles },
    { id: 'heatmap', label: 'Expense Heatmap', icon: Calendar },
    { id: 'budgets', label: 'Budgets', icon: Wallet },
    { id: 'reports', label: 'Reports', icon: FileSpreadsheet },
  ];

  return (
    <header className="bg-white border-b border-slate-200 sticky top-0 z-40 shadow-xs">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16">
          {/* Logo & Brand */}
          <div
            className="flex items-center space-x-3 cursor-pointer select-none"
            onClick={() => setActiveTab('dashboard')}
          >
            <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-indigo-600 to-indigo-700 flex items-center justify-center text-white shadow-md shadow-indigo-100">
              <span className="font-extrabold text-xl tracking-tight">₹</span>
            </div>
            <div>
              <div className="flex items-center space-x-2">
                <span className="font-extrabold text-xl text-slate-900 tracking-tight">SpendWise</span>
                <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-indigo-50 text-indigo-700 border border-indigo-200">
                  Student Edition
                </span>
              </div>
              <p className="text-xs text-slate-500 font-medium">Track. Understand. Improve Your Spending.</p>
            </div>
          </div>

          {/* Center / Right controls */}
          <div className="flex items-center space-x-3">
            {/* Quick date & data status badge */}
            <div className="hidden sm:flex items-center space-x-2 px-3 py-1.5 rounded-lg bg-slate-100 text-slate-700 text-xs font-medium border border-slate-200">
              <span className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse"></span>
              <span>Semester Session • Sep 2026</span>
            </div>

            {/* Data Management Dropdown */}
            <div className="relative">
              <button
                type="button"
                onClick={() => setShowMenu(!showMenu)}
                className="flex items-center space-x-1.5 px-3 py-1.5 rounded-lg border border-slate-300 text-slate-700 hover:bg-slate-50 text-xs font-semibold transition"
                title="Manage local dataset"
              >
                <RotateCcw className="w-3.5 h-3.5 text-slate-500" />
                <span>Dataset ({count})</span>
              </button>

              {showMenu && (
                <div
                  className="absolute right-0 mt-2 w-56 bg-white rounded-xl shadow-xl border border-slate-200 py-1.5 z-50 text-xs"
                  onClick={() => setShowMenu(false)}
                >
                  <div className="px-3 py-1.5 border-b border-slate-100">
                    <p className="font-semibold text-slate-800">Local Storage Engine</p>
                    <p className="text-slate-500 text-[11px] mt-0.5">Persistent across browser sessions</p>
                  </div>
                  <button
                    onClick={handleReset}
                    className="w-full text-left px-3 py-2 flex items-center space-x-2 text-slate-700 hover:bg-slate-50 transition"
                  >
                    <CheckCircle2 className="w-4 h-4 text-indigo-600" />
                    <span>Reset to Starter Student Data</span>
                  </button>
                  <button
                    onClick={onClearAll}
                    className="w-full text-left px-3 py-2 flex items-center space-x-2 text-rose-600 hover:bg-rose-50 transition"
                  >
                    <Trash2 className="w-4 h-4" />
                    <span>Wipe All Records (Start Empty)</span>
                  </button>
                </div>
              )}
            </div>

            {/* Quick Action Button */}
            <button
              type="button"
              onClick={() => setActiveTab('logger')}
              className="hidden sm:inline-flex items-center space-x-1.5 px-3.5 py-1.5 rounded-lg bg-indigo-600 hover:bg-indigo-700 text-white text-xs font-bold shadow-xs transition"
            >
              <PlusCircle className="w-4 h-4" />
              <span>Log Expense</span>
            </button>
          </div>
        </div>

        {/* Primary Navigation Tabs */}
        <nav className="flex space-x-1 overflow-x-auto pb-2 sm:pb-0 scrollbar-none border-t border-slate-100 sm:border-0 pt-1 sm:pt-0">
          {navItems.map((item) => {
            const Icon = item.icon;
            const isActive = activeTab === item.id;
            return (
              <button
                key={item.id}
                type="button"
                onClick={() => setActiveTab(item.id as ActiveTab)}
                className={`flex items-center space-x-2 px-3 py-2 text-xs font-semibold rounded-lg transition whitespace-nowrap ${
                  isActive
                    ? 'bg-indigo-50 text-indigo-700 border-b-2 sm:border-b-0 border-indigo-600 font-bold'
                    : 'text-slate-600 hover:text-slate-900 hover:bg-slate-50'
                }`}
              >
                <Icon className={`w-4 h-4 ${isActive ? 'text-indigo-600' : 'text-slate-400'}`} />
                <span>{item.label}</span>
                {item.badge !== undefined && (
                  <span
                    className={`ml-1 px-1.5 py-0.2 rounded-full text-[10px] font-bold ${
                      isActive ? 'bg-indigo-200 text-indigo-800' : 'bg-slate-200 text-slate-600'
                    }`}
                  >
                    {item.badge}
                  </span>
                )}
              </button>
            );
          })}
        </nav>
      </div>
    </header>
  );
};
