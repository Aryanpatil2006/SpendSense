import React, { useState, useMemo } from 'react';
import {
  FileSpreadsheet,
  Download,
  Copy,
  Upload,
  Printer,
  CheckCircle2,
  Calendar,
  AlertCircle,
  TrendingUp,
  Award,
  Wallet,
} from 'lucide-react';
import { Expense, Budget, CategoryType } from '../types';
import { CATEGORIES } from '../data/categories';
import {
  computeSummary,
  computeCategoryDistribution,
  computeBudgetProgress,
} from '../services/analyticsEngine';
import { exportExpensesToCSV, downloadCSV, parseCSVToExpenses } from '../services/storage';

interface ReportsViewProps {
  expenses: Expense[];
  budgets: Budget[];
  onImportExpenses: (newExpenses: Expense[]) => void;
}

export const ReportsView: React.FC<ReportsViewProps> = ({
  expenses,
  budgets,
  onImportExpenses,
}) => {
  const [selectedPeriod, setSelectedPeriod] = useState<'2026-09' | '2026-08' | 'all'>('2026-09');
  const [copySuccess, setCopySuccess] = useState(false);
  const [importErrors, setImportErrors] = useState<string[]>([]);
  const [importSuccess, setImportSuccess] = useState<string | null>(null);

  const filteredExpenses = useMemo(() => {
    if (selectedPeriod === 'all') return expenses;
    return expenses.filter((e) => e.date.startsWith(selectedPeriod));
  }, [expenses, selectedPeriod]);

  const summary = useMemo(() => {
    return computeSummary(expenses, '2026-09-07');
  }, [expenses]);

  const categoryDistribution = useMemo(() => {
    return computeCategoryDistribution(
      expenses,
      selectedPeriod === 'all' ? undefined : selectedPeriod
    );
  }, [expenses, selectedPeriod]);

  const budgetProgress = useMemo(() => {
    return computeBudgetProgress(expenses, budgets, selectedPeriod === '2026-08' ? '2026-08' : '2026-09');
  }, [expenses, budgets, selectedPeriod]);

  const totalPeriodSpend = useMemo(
    () => filteredExpenses.reduce((sum, e) => sum + e.amount, 0),
    [filteredExpenses]
  );

  const handleDownloadCSV = () => {
    const csv = exportExpensesToCSV(filteredExpenses);
    const filename = `spendwise_report_${selectedPeriod}_${Date.now()}.csv`;
    downloadCSV(csv, filename);
  };

  const handleCopyCSV = () => {
    const csv = exportExpensesToCSV(filteredExpenses);
    navigator.clipboard.writeText(csv);
    setCopySuccess(true);
    setTimeout(() => setCopySuccess(false), 2000);
  };

  const handlePrint = () => {
    window.print();
  };

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    setImportErrors([]);
    setImportSuccess(null);
    const file = e.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = (event) => {
      const text = event.target?.result as string;
      if (text) {
        const { expenses: imported, errors } = parseCSVToExpenses(text);
        if (errors.length > 0 && imported.length === 0) {
          setImportErrors(errors);
        } else {
          onImportExpenses(imported);
          setImportSuccess(`Successfully imported ${imported.length} expense records!`);
          if (errors.length > 0) setImportErrors(errors);
        }
      }
    };
    reader.readAsText(file);
  };

  return (
    <div className="space-y-6">
      {/* Header & Export Actions */}
      <div className="bg-white rounded-2xl p-6 border border-slate-200 shadow-xs flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
        <div>
          <div className="flex items-center space-x-2">
            <span className="p-2 rounded-xl bg-indigo-50 text-indigo-600 border border-indigo-200">
              <FileSpreadsheet className="w-5 h-5" />
            </span>
            <h1 className="text-2xl font-extrabold text-slate-900 tracking-tight">
              Expense Reports & CSV Export
            </h1>
          </div>
          <p className="text-sm text-slate-600 mt-1">
            Generate formal student financial reports, analyze budget health, and export or import data.
          </p>
        </div>

        {/* Action Buttons */}
        <div className="flex flex-wrap items-center gap-2">
          <button
            onClick={handleCopyCSV}
            className="px-3 py-1.5 rounded-lg border border-slate-300 text-slate-700 hover:bg-slate-50 text-xs font-semibold flex items-center space-x-1.5 transition"
            title="Copy CSV to clipboard"
          >
            {copySuccess ? (
              <>
                <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600" />
                <span className="text-emerald-700">Copied!</span>
              </>
            ) : (
              <>
                <Copy className="w-3.5 h-3.5 text-slate-500" />
                <span>Copy CSV</span>
              </>
            )}
          </button>

          <button
            onClick={handleDownloadCSV}
            className="px-3.5 py-1.5 rounded-lg bg-indigo-600 hover:bg-indigo-700 text-white text-xs font-bold flex items-center space-x-1.5 shadow-xs transition"
          >
            <Download className="w-3.5 h-3.5" />
            <span>Download CSV</span>
          </button>

          <button
            onClick={handlePrint}
            className="px-3 py-1.5 rounded-lg border border-slate-300 text-slate-700 hover:bg-slate-50 text-xs font-semibold flex items-center space-x-1.5 transition"
          >
            <Printer className="w-3.5 h-3.5 text-slate-500" />
            <span>Print Report</span>
          </button>
        </div>
      </div>

      {/* Scope Selector */}
      <div className="bg-white rounded-xl p-4 border border-slate-200 shadow-xs flex flex-col sm:flex-row sm:items-center justify-between gap-3">
        <div className="flex items-center space-x-2">
          <Calendar className="w-4 h-4 text-indigo-600" />
          <span className="text-xs font-bold text-slate-800">Report Scope:</span>
          <div className="inline-flex p-1 rounded-lg bg-slate-100 border border-slate-200">
            <button
              onClick={() => setSelectedPeriod('2026-09')}
              className={`px-3 py-1 rounded-md text-xs font-bold transition ${
                selectedPeriod === '2026-09'
                  ? 'bg-white text-indigo-700 shadow-xs'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              September 2026
            </button>
            <button
              onClick={() => setSelectedPeriod('2026-08')}
              className={`px-3 py-1 rounded-md text-xs font-bold transition ${
                selectedPeriod === '2026-08'
                  ? 'bg-white text-indigo-700 shadow-xs'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              August 2026
            </button>
            <button
              onClick={() => setSelectedPeriod('all')}
              className={`px-3 py-1 rounded-md text-xs font-bold transition ${
                selectedPeriod === 'all'
                  ? 'bg-white text-indigo-700 shadow-xs'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              All Recorded History
            </button>
          </div>
        </div>

        {/* CSV Import Trigger */}
        <label className="flex items-center space-x-1.5 text-xs text-indigo-600 hover:text-indigo-800 font-bold cursor-pointer">
          <Upload className="w-4 h-4" />
          <span>Import Custom CSV</span>
          <input
            type="file"
            accept=".csv"
            onChange={handleFileUpload}
            className="hidden"
          />
        </label>
      </div>

      {importSuccess && (
        <div className="p-3 rounded-xl bg-emerald-50 border border-emerald-200 text-emerald-800 text-xs font-bold flex items-center space-x-2">
          <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
          <span>{importSuccess}</span>
        </div>
      )}

      {importErrors.length > 0 && (
        <div className="p-3 rounded-xl bg-rose-50 border border-rose-200 text-rose-800 text-xs font-medium space-y-1">
          <span className="font-bold block">CSV Import Warnings:</span>
          {importErrors.slice(0, 3).map((err, idx) => (
            <p key={idx}>{err}</p>
          ))}
        </div>
      )}

      {/* Formal Report Card */}
      <div className="bg-white rounded-2xl p-6 sm:p-8 border border-slate-200 shadow-xs space-y-6">
        <div className="border-b border-slate-200 pb-4">
          <div className="flex justify-between items-start">
            <div>
              <h2 className="text-xl font-extrabold text-slate-900">
                SpendWise Student Financial Statement
              </h2>
              <p className="text-xs text-slate-500 mt-0.5">
                Report Period: {selectedPeriod === 'all' ? 'All-Time' : selectedPeriod} • Generated for Personal Expense Review
              </p>
            </div>
            <div className="text-right">
              <span className="text-xs font-bold text-slate-500 block">Total Disbursed</span>
              <span className="text-xl font-black text-indigo-700 block">
                ₹{totalPeriodSpend.toLocaleString()}
              </span>
            </div>
          </div>
        </div>

        {/* Metric Summary Strip */}
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-4 p-4 rounded-xl bg-slate-50 border border-slate-200">
          <div>
            <span className="text-[10px] uppercase font-bold text-slate-400 block">Recorded Transactions</span>
            <span className="text-base font-extrabold text-slate-900 mt-0.5 block">
              {filteredExpenses.length} entries
            </span>
          </div>
          <div>
            <span className="text-[10px] uppercase font-bold text-slate-400 block">Leading Category</span>
            <span className="text-base font-extrabold text-slate-900 mt-0.5 block">
              {summary.highestCategory}
            </span>
          </div>
          <div>
            <span className="text-[10px] uppercase font-bold text-slate-400 block">Daily Burn Rate</span>
            <span className="text-base font-extrabold text-slate-900 mt-0.5 block">
              ₹{summary.dailyAverageThisMonth}/day
            </span>
          </div>
          <div>
            <span className="text-[10px] uppercase font-bold text-slate-400 block">Monthly Comparison</span>
            <span className="text-base font-extrabold text-slate-900 mt-0.5 block">
              {summary.monthOverMonthGrowth >= 0 ? `+${summary.monthOverMonthGrowth}%` : `${summary.monthOverMonthGrowth}%`}
            </span>
          </div>
        </div>

        {/* Table 1: Category Totals */}
        <div className="space-y-3">
          <h3 className="text-sm font-extrabold text-slate-900 uppercase tracking-wider">
            1. Category Distribution Summary
          </h3>
          <div className="overflow-x-auto">
            <table className="w-full text-xs text-left">
              <thead className="bg-slate-100/75 text-slate-600 uppercase text-[10px] font-bold">
                <tr>
                  <th className="px-4 py-2.5 rounded-l-lg">Category</th>
                  <th className="px-4 py-2.5">Amount (INR)</th>
                  <th className="px-4 py-2.5">Share of Total</th>
                  <th className="px-4 py-2.5 rounded-r-lg">Entries Count</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {categoryDistribution.map((c) => {
                  const meta = CATEGORIES[c.category];
                  return (
                    <tr key={c.category} className="hover:bg-slate-50/60 transition">
                      <td className="px-4 py-2.5 font-bold text-slate-800 flex items-center space-x-2">
                        <span>{meta.emoji}</span>
                        <span>{c.category}</span>
                      </td>
                      <td className="px-4 py-2.5 font-extrabold text-slate-900">
                        ₹{c.amount.toLocaleString()}
                      </td>
                      <td className="px-4 py-2.5 font-semibold text-slate-600">{c.percentage}%</td>
                      <td className="px-4 py-2.5 text-slate-500">{c.count}</td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        </div>

        {/* Table 2: Budget Status */}
        <div className="space-y-3">
          <h3 className="text-sm font-extrabold text-slate-900 uppercase tracking-wider">
            2. Budget Adherence Status
          </h3>
          <div className="overflow-x-auto">
            <table className="w-full text-xs text-left">
              <thead className="bg-slate-100/75 text-slate-600 uppercase text-[10px] font-bold">
                <tr>
                  <th className="px-4 py-2.5 rounded-l-lg">Category</th>
                  <th className="px-4 py-2.5">Budget Limit</th>
                  <th className="px-4 py-2.5">Actual Spent</th>
                  <th className="px-4 py-2.5">Remaining</th>
                  <th className="px-4 py-2.5">Utilized %</th>
                  <th className="px-4 py-2.5 rounded-r-lg">Status</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {budgetProgress.map((b) => (
                  <tr key={b.category} className="hover:bg-slate-50/60 transition">
                    <td className="px-4 py-2.5 font-bold text-slate-800">{b.category}</td>
                    <td className="px-4 py-2.5 text-slate-600">₹{b.monthlyLimit.toLocaleString()}</td>
                    <td className="px-4 py-2.5 font-bold text-slate-900">₹{b.spent.toLocaleString()}</td>
                    <td className="px-4 py-2.5 text-emerald-700 font-semibold">
                      ₹{b.remaining.toLocaleString()}
                    </td>
                    <td className="px-4 py-2.5 font-extrabold text-slate-800">{b.percentageUsed}%</td>
                    <td className="px-4 py-2.5">
                      <span
                        className={`px-2 py-0.5 rounded-full text-[10px] font-bold ${
                          b.status === 'Exceeded'
                            ? 'bg-rose-100 text-rose-800'
                            : b.status === 'Near Limit'
                            ? 'bg-orange-100 text-orange-800'
                            : b.status === 'Moderate'
                            ? 'bg-amber-100 text-amber-800'
                            : 'bg-emerald-100 text-emerald-800'
                        }`}
                      >
                        {b.status}
                      </span>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </div>
  );
};
