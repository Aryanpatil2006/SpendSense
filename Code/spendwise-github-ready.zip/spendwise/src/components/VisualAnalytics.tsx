import React, { useState, useMemo } from 'react';
import {
  Sparkles,
  AlertTriangle,
  PieChart,
  BarChart3,
  TrendingUp,
  CreditCard,
  CheckCircle2,
  Calendar,
  Info,
  ShieldAlert,
} from 'lucide-react';
import { Expense, Budget, CategoryType } from '../types';
import { CATEGORIES, ALL_CATEGORIES } from '../data/categories';
import {
  computeSpendingPersonality,
  computeCategoryDistribution,
  computeWeekendVsWeekday,
  computeSummary,
} from '../services/analyticsEngine';
import { detectAnomalies } from '../services/anomalyDetector';

interface VisualAnalyticsProps {
  expenses: Expense[];
  budgets: Budget[];
}

export const VisualAnalytics: React.FC<VisualAnalyticsProps> = ({ expenses, budgets }) => {
  const [selectedRange, setSelectedRange] = useState<'all' | '2026-09' | '2026-08'>('2026-09');
  const [hoveredCategory, setHoveredCategory] = useState<CategoryType | null>(null);

  const personality = useMemo(() => {
    return computeSpendingPersonality(expenses, budgets, selectedRange === 'all' ? '2026-09' : selectedRange);
  }, [expenses, budgets, selectedRange]);

  const anomalies = useMemo(() => {
    return detectAnomalies(expenses);
  }, [expenses]);

  const categoryDistribution = useMemo(() => {
    return computeCategoryDistribution(expenses, selectedRange === 'all' ? undefined : selectedRange);
  }, [expenses, selectedRange]);

  const totalFilteredSpend = useMemo(() => {
    return categoryDistribution.reduce((sum, c) => sum + c.amount, 0);
  }, [categoryDistribution]);

  const weekendData = useMemo(() => {
    return computeWeekendVsWeekday(expenses, selectedRange === 'all' ? '2026-09' : selectedRange);
  }, [expenses, selectedRange]);

  // Daily totals for daily bar chart (September 1 - 7)
  const dailyBars = useMemo(() => {
    const list: { day: string; date: string; amount: number; isWeekend: boolean }[] = [];
    const sepExpenses = expenses.filter((e) => e.date.startsWith('2026-09'));

    const dayMap = new Map<string, number>();
    for (const exp of sepExpenses) {
      dayMap.set(exp.date, (dayMap.get(exp.date) || 0) + exp.amount);
    }

    for (let d = 1; d <= 7; d++) {
      const dateStr = `2026-09-0${d}`;
      const dt = new Date(dateStr + 'T12:00:00');
      const dayName = dt.toLocaleDateString('en-US', { weekday: 'short' });
      const dayOfWeek = dt.getDay();
      const isWeekend = dayOfWeek === 0 || dayOfWeek === 6;
      list.push({
        day: `${dayName} ${d}`,
        date: dateStr,
        amount: dayMap.get(dateStr) || 0,
        isWeekend,
      });
    }

    return list;
  }, [expenses]);

  const maxDailyAmount = Math.max(...dailyBars.map((b) => b.amount), 500);

  // Payment method distribution
  const paymentDistribution = useMemo(() => {
    const counts: Record<string, { amount: number; count: number }> = {
      UPI: { amount: 0, count: 0 },
      Cash: { amount: 0, count: 0 },
      'Debit Card': { amount: 0, count: 0 },
      'Credit Card': { amount: 0, count: 0 },
      'Net Banking': { amount: 0, count: 0 },
    };

    for (const exp of expenses) {
      if (counts[exp.paymentMethod]) {
        counts[exp.paymentMethod].amount += exp.amount;
        counts[exp.paymentMethod].count += 1;
      }
    }

    const total = expenses.reduce((s, e) => s + e.amount, 0);
    return Object.entries(counts).map(([method, data]) => ({
      method,
      amount: data.amount,
      count: data.count,
      percentage: total > 0 ? Math.round((data.amount / total) * 100) : 0,
    }));
  }, [expenses]);

  return (
    <div className="space-y-6">
      {/* Header with Month Switcher */}
      <div className="bg-white rounded-2xl p-6 border border-slate-200 shadow-xs flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
        <div>
          <h1 className="text-2xl font-extrabold text-slate-900 tracking-tight flex items-center gap-2">
            <Sparkles className="w-6 h-6 text-indigo-600" />
            <span>Visual Analytics & Smart Insights</span>
          </h1>
          <p className="text-sm text-slate-600 mt-0.5">
            Spending personality classification, rule-based anomaly detection, and interactive visual charts.
          </p>
        </div>

        <div className="inline-flex p-1 rounded-xl bg-slate-100 border border-slate-200 self-start sm:self-auto">
          <button
            onClick={() => setSelectedRange('2026-09')}
            className={`px-3 py-1.5 rounded-lg text-xs font-bold transition ${
              selectedRange === '2026-09'
                ? 'bg-white text-indigo-700 shadow-xs'
                : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            September 2026
          </button>
          <button
            onClick={() => setSelectedRange('2026-08')}
            className={`px-3 py-1.5 rounded-lg text-xs font-bold transition ${
              selectedRange === '2026-08'
                ? 'bg-white text-indigo-700 shadow-xs'
                : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            August 2026
          </button>
          <button
            onClick={() => setSelectedRange('all')}
            className={`px-3 py-1.5 rounded-lg text-xs font-bold transition ${
              selectedRange === 'all'
                ? 'bg-white text-indigo-700 shadow-xs'
                : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            All-Time
          </button>
        </div>
      </div>

      {/* Feature 1: Spending Personality Showcase */}
      <div className={`rounded-2xl p-6 sm:p-8 bg-gradient-to-br ${personality.accentBg} border border-slate-200 shadow-xs space-y-4`}>
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
          <div className="flex items-center space-x-2">
            <span className="text-xs font-bold uppercase tracking-wider text-slate-500">
              Unique Analytical Feature
            </span>
            <span className={`px-2.5 py-0.5 rounded-full text-xs font-extrabold border ${personality.badgeColor}`}>
              {personality.type}
            </span>
          </div>

          <span className="text-xs font-bold text-slate-600 bg-white/80 px-3 py-1 rounded-lg border border-slate-200">
            Key Metric: {personality.keyMetric}
          </span>
        </div>

        <div>
          <h2 className="text-2xl sm:text-3xl font-black text-slate-900 tracking-tight">
            {personality.title}
          </h2>
          <p className="text-sm font-semibold text-slate-700 mt-1 italic">{personality.tagline}</p>
        </div>

        <p className="text-sm text-slate-700 leading-relaxed max-w-3xl">
          {personality.description}
        </p>

        {/* Student actionable advice */}
        <div className="p-4 rounded-xl bg-white/90 border border-slate-200 shadow-2xs flex items-start space-x-3">
          <Info className="w-5 h-5 text-indigo-600 shrink-0 mt-0.5" />
          <div>
            <span className="text-xs font-extrabold text-slate-900 block">Personalized Student Advice</span>
            <p className="text-xs text-slate-600 mt-0.5">{personality.studentAdvice}</p>
          </div>
        </div>

        {/* All Personalities Legend */}
        <div className="pt-2 border-t border-slate-200/60">
          <span className="text-[11px] font-bold text-slate-500 uppercase tracking-wider block mb-2">
            System Personality Profiles Supported:
          </span>
          <div className="flex flex-wrap gap-2 text-xs">
            {['Foodie 🍔', 'Academic Focused 📚', 'Transport Heavy 🚌', 'Entertainment Focused 🍿', 'Saver 💰', 'Balanced Spender ⚖️'].map((p) => (
              <span key={p} className="px-2.5 py-1 rounded-lg bg-white/70 text-slate-700 font-medium border border-slate-200">
                {p}
              </span>
            ))}
          </div>
        </div>
      </div>

      {/* Feature 2: Spending Anomaly Detector */}
      <div className="bg-white rounded-2xl p-6 border border-slate-200 shadow-xs space-y-4">
        <div className="flex items-center justify-between">
          <div className="flex items-center space-x-2">
            <span className="p-2 rounded-xl bg-rose-50 text-rose-600 border border-rose-200">
              <ShieldAlert className="w-5 h-5" />
            </span>
            <div>
              <h2 className="text-lg font-extrabold text-slate-900">Spending Anomaly Detector</h2>
              <p className="text-xs text-slate-500">
                Statistical outlier engine identifies expenses significantly higher than category averages.
              </p>
            </div>
          </div>

          <span className="text-xs font-bold px-2.5 py-1 rounded-full bg-rose-100 text-rose-800 border border-rose-200">
            {anomalies.length} {anomalies.length === 1 ? 'Anomaly Flagged' : 'Anomalies Flagged'}
          </span>
        </div>

        {anomalies.length === 0 ? (
          <div className="p-6 text-center bg-emerald-50 rounded-xl border border-emerald-200">
            <CheckCircle2 className="w-8 h-8 text-emerald-600 mx-auto mb-2" />
            <p className="text-xs font-bold text-emerald-900">No Unusual Expenses Detected</p>
            <p className="text-[11px] text-emerald-700 mt-0.5">
              All student expenditures are within normal category variance bounds.
            </p>
          </div>
        ) : (
          <div className="space-y-3">
            {anomalies.map((anom, idx) => {
              const meta = CATEGORIES[anom.expense.category];
              return (
                <div
                  key={idx}
                  className="p-4 rounded-xl border border-rose-200 bg-rose-50/40 space-y-3"
                >
                  <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
                    <div className="flex items-center space-x-3">
                      <span className="text-2xl p-2 bg-white rounded-lg border border-rose-100">
                        {meta.emoji}
                      </span>
                      <div>
                        <div className="flex items-center space-x-2">
                          <span className="text-sm font-bold text-slate-900">{anom.expense.description}</span>
                          <span className="text-[10px] uppercase font-extrabold px-2 py-0.5 rounded-full bg-rose-200 text-rose-900">
                            Unusual Expense Detected
                          </span>
                        </div>
                        <p className="text-xs text-slate-500 mt-0.5">
                          Date: {anom.expense.date} • {anom.expense.category}
                        </p>
                      </div>
                    </div>

                    <div className="text-right sm:self-auto self-start">
                      <span className="text-lg font-extrabold text-rose-700 block">
                        ₹{anom.expense.amount.toLocaleString()}
                      </span>
                      <span className="text-[10px] font-semibold text-rose-600 block">
                        +{anom.differenceFromAvg.toLocaleString()} above average
                      </span>
                    </div>
                  </div>

                  {/* Math Breakdown Row */}
                  <div className="grid grid-cols-2 sm:grid-cols-3 gap-2 text-xs pt-2 border-t border-rose-200/60">
                    <div className="p-2 bg-white/80 rounded-lg border border-rose-100">
                      <span className="text-[10px] text-slate-500 block">Category Baseline Avg</span>
                      <span className="font-extrabold text-slate-800 mt-0.5 block">
                        ₹{anom.categoryAverage.toLocaleString()}
                      </span>
                    </div>
                    <div className="p-2 bg-white/80 rounded-lg border border-rose-100">
                      <span className="text-[10px] text-slate-500 block">Multiplier Ratio</span>
                      <span className="font-extrabold text-rose-700 mt-0.5 block">
                        {anom.ratioToAvg}x higher than normal
                      </span>
                    </div>
                    <div className="p-2 bg-white/80 rounded-lg border border-rose-100 col-span-2 sm:col-span-1">
                      <span className="text-[10px] text-slate-500 block">Analytical Note</span>
                      <span className="text-[11px] font-medium text-slate-700 mt-0.5 block truncate">
                        Non-judgmental student review
                      </span>
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </div>

      {/* Visual Charts Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Chart 1: Category Distribution Interactive SVG Donut */}
        <div className="bg-white rounded-2xl p-6 border border-slate-200 shadow-xs space-y-4">
          <div className="flex items-center justify-between">
            <span className="text-xs font-bold uppercase tracking-wider text-slate-700 flex items-center gap-1.5">
              <PieChart className="w-4 h-4 text-indigo-600" />
              Category Spending Breakdown
            </span>
            <span className="text-xs font-bold text-slate-900">
              Total: ₹{totalFilteredSpend.toLocaleString()}
            </span>
          </div>

          {/* SVG Donut */}
          <div className="flex flex-col sm:flex-row items-center gap-6 py-2">
            <div className="relative w-44 h-44 shrink-0">
              <svg viewBox="0 0 100 100" className="w-full h-full -rotate-90">
                {(() => {
                  let accumulatedPercent = 0;
                  return categoryDistribution.map((item) => {
                    const meta = CATEGORIES[item.category];
                    const strokeDasharray = `${item.percentage} ${100 - item.percentage}`;
                    const strokeDashoffset = -accumulatedPercent;
                    accumulatedPercent += item.percentage;
                    const isHovered = hoveredCategory === item.category;

                    return (
                      <circle
                        key={item.category}
                        cx="50"
                        cy="50"
                        r="38"
                        fill="transparent"
                        stroke={meta.color}
                        strokeWidth={isHovered ? '15' : '12'}
                        strokeDasharray={strokeDasharray}
                        strokeDashoffset={strokeDashoffset}
                        pathLength="100"
                        className="transition-all duration-300 cursor-pointer"
                        onMouseEnter={() => setHoveredCategory(item.category)}
                        onMouseLeave={() => setHoveredCategory(null)}
                      />
                    );
                  });
                })()}
              </svg>
              <div className="absolute inset-0 flex flex-col items-center justify-center pointer-events-none text-center">
                <span className="text-[10px] font-bold text-slate-400 uppercase">
                  {hoveredCategory || 'Active'}
                </span>
                <span className="text-sm font-extrabold text-slate-900">
                  {hoveredCategory
                    ? `${categoryDistribution.find((c) => c.category === hoveredCategory)?.percentage || 0}%`
                    : '100%'}
                </span>
              </div>
            </div>

            {/* Legend List */}
            <div className="space-y-1.5 flex-1 w-full max-h-52 overflow-y-auto pr-1">
              {categoryDistribution.map((item) => {
                const meta = CATEGORIES[item.category];
                const isHovered = hoveredCategory === item.category;

                return (
                  <div
                    key={item.category}
                    onMouseEnter={() => setHoveredCategory(item.category)}
                    onMouseLeave={() => setHoveredCategory(null)}
                    className={`flex items-center justify-between p-2 rounded-lg text-xs transition cursor-pointer ${
                      isHovered ? 'bg-slate-100 font-bold' : 'hover:bg-slate-50'
                    }`}
                  >
                    <div className="flex items-center space-x-2">
                      <span className="w-3 h-3 rounded-full shrink-0" style={{ backgroundColor: meta.color }} />
                      <span className="text-slate-800 font-medium">{item.category}</span>
                    </div>
                    <div className="text-right">
                      <span className="font-extrabold text-slate-900">₹{item.amount.toLocaleString()}</span>
                      <span className="text-[10px] text-slate-500 ml-1.5">({item.percentage}%)</span>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        </div>

        {/* Chart 2: Daily Spending Bar Chart */}
        <div className="bg-white rounded-2xl p-6 border border-slate-200 shadow-xs space-y-4">
          <div className="flex items-center justify-between">
            <span className="text-xs font-bold uppercase tracking-wider text-slate-700 flex items-center gap-1.5">
              <BarChart3 className="w-4 h-4 text-indigo-600" />
              Daily Spend Velocity (Sep 1–7)
            </span>
            <span className="text-[11px] text-slate-500">Max day: ₹{maxDailyAmount.toLocaleString()}</span>
          </div>

          <div className="h-52 flex items-end justify-between gap-2 pt-6 pb-2">
            {dailyBars.map((bar) => {
              const heightPct = maxDailyAmount > 0 ? (bar.amount / maxDailyAmount) * 100 : 0;

              return (
                <div key={bar.date} className="flex-1 flex flex-col items-center h-full justify-end group">
                  <div className="text-[10px] font-bold text-slate-700 opacity-0 group-hover:opacity-100 transition mb-1">
                    ₹{bar.amount}
                  </div>
                  <div className="w-full max-w-[32px] bg-slate-100 rounded-t-lg h-full flex items-end">
                    <div
                      className={`w-full rounded-t-lg transition-all duration-500 ${
                        bar.amount > 1000
                          ? 'bg-rose-500'
                          : bar.isWeekend
                          ? 'bg-purple-500'
                          : 'bg-indigo-600'
                      }`}
                      style={{ height: `${Math.max(8, heightPct)}%` }}
                    />
                  </div>
                  <span className="text-[10px] font-semibold text-slate-500 mt-2 truncate max-w-[40px] text-center">
                    {bar.day}
                  </span>
                </div>
              );
            })}
          </div>

          <div className="flex items-center justify-between text-xs text-slate-500 pt-2 border-t border-slate-100">
            <div className="flex items-center space-x-3">
              <span className="flex items-center gap-1">
                <span className="w-2.5 h-2.5 rounded-sm bg-indigo-600"></span> Weekday
              </span>
              <span className="flex items-center gap-1">
                <span className="w-2.5 h-2.5 rounded-sm bg-purple-500"></span> Weekend
              </span>
              <span className="flex items-center gap-1">
                <span className="w-2.5 h-2.5 rounded-sm bg-rose-500"></span> Spike (&gt;₹1000)
              </span>
            </div>
          </div>
        </div>
      </div>

      {/* Secondary Analytics Row: Weekend vs Weekday & Payment Method */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {/* Weekend vs Weekday */}
        <div className="bg-white rounded-2xl p-6 border border-slate-200 shadow-xs space-y-4">
          <h3 className="text-sm font-bold text-slate-900 flex items-center gap-2">
            <Calendar className="w-4 h-4 text-indigo-600" />
            Weekend vs. Weekday Outflow Dynamics
          </h3>

          <div className="space-y-3">
            <div>
              <div className="flex justify-between text-xs font-bold mb-1">
                <span className="text-indigo-700">Weekday Expenses (Mon–Fri)</span>
                <span>₹{weekendData.weekdayTotal.toLocaleString()} ({weekendData.weekdayPercentage}%)</span>
              </div>
              <div className="w-full h-3 rounded-full bg-slate-100 overflow-hidden">
                <div
                  className="h-full bg-indigo-600 rounded-full"
                  style={{ width: `${weekendData.weekdayPercentage}%` }}
                />
              </div>
              <span className="text-[10px] text-slate-500 mt-0.5 block">
                Daily average: ₹{weekendData.weekdayAvgPerDay} / weekday
              </span>
            </div>

            <div>
              <div className="flex justify-between text-xs font-bold mb-1">
                <span className="text-purple-700">Weekend Expenses (Sat–Sun)</span>
                <span>₹{weekendData.weekendTotal.toLocaleString()} ({weekendData.weekendPercentage}%)</span>
              </div>
              <div className="w-full h-3 rounded-full bg-slate-100 overflow-hidden">
                <div
                  className="h-full bg-purple-500 rounded-full"
                  style={{ width: `${weekendData.weekendPercentage}%` }}
                />
              </div>
              <span className="text-[10px] text-slate-500 mt-0.5 block">
                Daily average: ₹{weekendData.weekendAvgPerDay} / weekend day
              </span>
            </div>
          </div>
        </div>

        {/* Payment Methods */}
        <div className="bg-white rounded-2xl p-6 border border-slate-200 shadow-xs space-y-4">
          <h3 className="text-sm font-bold text-slate-900 flex items-center gap-2">
            <CreditCard className="w-4 h-4 text-indigo-600" />
            Student Payment Method Distribution
          </h3>

          <div className="space-y-2.5">
            {paymentDistribution.map((item) => (
              <div key={item.method} className="flex items-center justify-between text-xs">
                <div className="flex items-center space-x-2">
                  <span className="font-semibold text-slate-800">{item.method}</span>
                  <span className="text-[10px] text-slate-500">({item.count} txns)</span>
                </div>
                <div className="flex items-center space-x-2">
                  <div className="w-24 h-2 rounded-full bg-slate-100 overflow-hidden hidden sm:block">
                    <div className="h-full bg-indigo-500 rounded-full" style={{ width: `${item.percentage}%` }} />
                  </div>
                  <span className="font-bold text-slate-900 w-16 text-right">
                    ₹{item.amount.toLocaleString()}
                  </span>
                  <span className="text-[10px] text-slate-500 w-8 text-right font-medium">
                    {item.percentage}%
                  </span>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
};
