import { CategoryType } from '../types';

export interface CategoryMeta {
  type: CategoryType;
  label: string;
  icon: string; // Lucide icon identifier or emoji
  emoji: string;
  color: string;
  bgLight: string;
  borderColor: string;
  textColor: string;
  keywords: string[];
}

export const CATEGORIES: Record<CategoryType, CategoryMeta> = {
  Food: {
    type: 'Food',
    label: 'Food & Dining',
    icon: 'Utensils',
    emoji: '🍔',
    color: '#f97316', // Orange
    bgLight: 'bg-orange-50',
    borderColor: 'border-orange-200',
    textColor: 'text-orange-700',
    keywords: [
      'lunch', 'dinner', 'breakfast', 'pizza', 'burger', 'cafe', 'coffee', 'tea', 'chai',
      'samosa', 'snacks', 'biryani', 'canteen', 'mess', 'groceries', 'zomato', 'swiggy',
      'maggi', 'sandwich', 'shawarma', 'juice', 'shake', 'restaurant', 'icecream', 'snack', 'dosa'
    ],
  },
  Transport: {
    type: 'Transport',
    label: 'Transportation',
    icon: 'Bus',
    emoji: '🚌',
    color: '#0284c7', // Sky blue
    bgLight: 'bg-sky-50',
    borderColor: 'border-sky-200',
    textColor: 'text-sky-700',
    keywords: [
      'bus', 'train', 'metro', 'uber', 'ola', 'auto', 'rickshaw', 'fuel', 'petrol', 'diesel',
      'ticket', 'cab', 'travel', 'pass', 'toll', 'parking', 'bike', 'scooter', 'fare', 'flight'
    ],
  },
  Academic: {
    type: 'Academic',
    label: 'Academic & Study',
    icon: 'BookOpen',
    emoji: '📚',
    color: '#7c3aed', // Purple
    bgLight: 'bg-purple-50',
    borderColor: 'border-purple-200',
    textColor: 'text-purple-700',
    keywords: [
      'notebook', 'book', 'pen', 'stationery', 'xerox', 'print', 'printing', 'photocopy',
      'tuition', 'course', 'exam', 'fees', 'library', 'project', 'lab', 'record', 'textbook',
      'calculator', 'udemy', 'coursera', 'assignment', 'file'
    ],
  },
  Entertainment: {
    type: 'Entertainment',
    label: 'Entertainment',
    icon: 'Film',
    emoji: '🍿',
    color: '#ec4899', // Pink
    bgLight: 'bg-pink-50',
    borderColor: 'border-pink-200',
    textColor: 'text-pink-700',
    keywords: [
      'netflix', 'movie', 'spotify', 'game', 'gaming', 'prime', 'cinema', 'theatre',
      'concert', 'party', 'outing', 'club', 'youtube', 'hotstar', 'steam', 'playstation',
      'billiards', 'bowling', 'fair', 'ticket'
    ],
  },
  Shopping: {
    type: 'Shopping',
    label: 'Shopping',
    icon: 'ShoppingBag',
    emoji: '🛍️',
    color: '#059669', // Emerald
    bgLight: 'bg-emerald-50',
    borderColor: 'border-emerald-200',
    textColor: 'text-emerald-700',
    keywords: [
      'clothes', 'shoes', 'amazon', 'flipkart', 'mall', 'myntra', 'electronics', 'gadget',
      'tshirt', 'jeans', 'watch', 'bag', 'backpack', 'earphones', 'headphones', 'charger',
      'cable', 'perfume', 'cosmetics', 'accessories'
    ],
  },
  Health: {
    type: 'Health',
    label: 'Health & Wellness',
    icon: 'HeartPulse',
    emoji: '💊',
    color: '#e11d48', // Rose
    bgLight: 'bg-rose-50',
    borderColor: 'border-rose-200',
    textColor: 'text-rose-700',
    keywords: [
      'medicine', 'doctor', 'pharmacy', 'clinic', 'gym', 'fitness', 'hospital', 'vitamins',
      'tablets', 'meds', 'paracetamol', 'consultation', 'dentist', 'firstaid', 'protein'
    ],
  },
  Bills: {
    type: 'Bills',
    label: 'Bills & Utilities',
    icon: 'Receipt',
    emoji: '⚡',
    color: '#d97706', // Amber
    bgLight: 'bg-amber-50',
    borderColor: 'border-amber-200',
    textColor: 'text-amber-700',
    keywords: [
      'recharge', 'wifi', 'electricity', 'phone', 'rent', 'hostel', 'water', 'subscription',
      'broadband', 'mobile', 'pg', 'maintenance', 'laundry'
    ],
  },
  Other: {
    type: 'Other',
    label: 'Other / Misc',
    icon: 'MoreHorizontal',
    emoji: '📦',
    color: '#64748b', // Slate
    bgLight: 'bg-slate-50',
    borderColor: 'border-slate-200',
    textColor: 'text-slate-700',
    keywords: ['miscellaneous', 'other', 'general', 'cash', 'donation', 'gift', 'lost', 'penalty'],
  },
};

export const ALL_CATEGORIES = Object.keys(CATEGORIES) as CategoryType[];
