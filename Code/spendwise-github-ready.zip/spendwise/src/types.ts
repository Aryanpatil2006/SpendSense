export type CategoryType =
  | 'Food'
  | 'Transport'
  | 'Academic'
  | 'Entertainment'
  | 'Shopping'
  | 'Health'
  | 'Bills'
  | 'Other';

export type PaymentMethod = 'UPI' | 'Cash' | 'Debit Card' | 'Credit Card' | 'Net Banking';

export interface Expense {
  id: string;
  amount: number;
  description: string;
  category: CategoryType;
  date: string; // YYYY-MM-DD
  paymentMethod: PaymentMethod;
  note?: string;
  createdAt: number;
}

export interface Budget {
  category: CategoryType;
  monthlyLimit: number;
}

export type BudgetStatus = 'Safe' | 'Moderate' | 'Near Limit' | 'Exceeded';

export interface CategoryBudgetProgress {
  category: CategoryType;
  monthlyLimit: number;
  spent: number;
  remaining: number;
  percentageUsed: number;
  status: BudgetStatus;
}

export type PersonalityType =
  | 'Foodie'
  | 'Balanced Spender'
  | 'Saver'
  | 'Transport Heavy'
  | 'Entertainment Focused'
  | 'Academic Focused';

export interface SpendingPersonality {
  type: PersonalityType;
  title: string;
  tagline: string;
  description: string;
  badgeColor: string;
  accentBg: string;
  keyMetric: string;
  studentAdvice: string;
  stats: {
    dominantCategory?: CategoryType;
    dominantPercentage: number;
    savingsRateEstimate?: number;
    transactionCount: number;
    totalSpent: number;
  };
}

export interface ExpenseAnomaly {
  expense: Expense;
  categoryAverage: number;
  differenceFromAvg: number;
  ratioToAvg: number;
  severity: 'moderate' | 'high' | 'extreme';
  message: string;
}

export interface SmartInsight {
  id: string;
  type: 'info' | 'warning' | 'positive' | 'tip';
  title: string;
  message: string;
  metric?: string;
  category?: CategoryType;
}

export interface ParsedExpenseResult {
  amount: number | null;
  description: string;
  category: CategoryType;
  date: string;
  paymentMethod: PaymentMethod;
  rawText: string;
  confidence: number;
  matchedKeywords: string[];
}

export interface FilterOptions {
  search: string;
  category: string; // 'all' or CategoryType
  startDate: string;
  endDate: string;
  minAmount: string;
  maxAmount: string;
  paymentMethod: string; // 'all' or PaymentMethod
  sortBy: 'newest' | 'oldest' | 'highest' | 'lowest';
}
