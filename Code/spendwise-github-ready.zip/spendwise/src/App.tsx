import React, { useState, useEffect } from 'react';
import { Expense, Budget } from './types';
import {
  loadExpenses,
  saveExpenses,
  loadBudgets,
  saveBudgets,
} from './services/storage';
import { INITIAL_SAMPLE_EXPENSES, DEFAULT_BUDGETS } from './data/sampleData';
import { Navbar, ActiveTab } from './components/Navbar';
import { Dashboard } from './components/Dashboard';
import { SmartLogger } from './components/SmartLogger';
import { ExpenseTimeline } from './components/ExpenseTimeline';
import { ExpenseHeatmap } from './components/ExpenseHeatmap';
import { BudgetManager } from './components/BudgetManager';
import { VisualAnalytics } from './components/VisualAnalytics';
import { ReportsView } from './components/ReportsView';
import { EditExpenseModal } from './components/EditExpenseModal';
import { CheckCircle2, Info, Heart, ShieldAlert } from 'lucide-react';

export default function App() {
  const [expenses, setExpenses] = useState<Expense[]>(() => {
    return loadExpenses();
  });

  const [budgets, setBudgets] = useState<Budget[]>(() => {
    return loadBudgets();
  });

  const [activeTab, setActiveTab] = useState<ActiveTab>('dashboard');
  const [editingExpense, setEditingExpense] = useState<Expense | null>(null);
  const [toastMessage, setToastMessage] = useState<string | null>(null);

  // Sync to local storage
  useEffect(() => {
    saveExpenses(expenses);
  }, [expenses]);

  useEffect(() => {
    saveBudgets(budgets);
  }, [budgets]);

  const showToast = (msg: string) => {
    setToastMessage(msg);
    setTimeout(() => {
      setToastMessage(null);
    }, 3000);
  };

  // Expense Handlers
  const handleAddExpense = (newExpense: Expense) => {
    setExpenses((prev) => [newExpense, ...prev]);
    showToast(`Logged ₹${newExpense.amount} for "${newExpense.description}"`);
  };

  const handleUpdateExpense = (updated: Expense) => {
    setExpenses((prev) => prev.map((e) => (e.id === updated.id ? updated : e)));
    setEditingExpense(null);
    showToast(`Updated expense "${updated.description}"`);
  };

  const handleDeleteExpense = (id: string) => {
    setExpenses((prev) => prev.filter((e) => e.id !== id));
    showToast('Expense entry deleted');
  };

  const handleUpdateBudgets = (newBudgets: Budget[]) => {
    setBudgets(newBudgets);
    showToast('Monthly budget limits updated');
  };

  const handleResetData = () => {
    if (window.confirm('Reset expense records and budgets to demo student dataset?')) {
      setExpenses(INITIAL_SAMPLE_EXPENSES);
      setBudgets(DEFAULT_BUDGETS);
      showToast('Reset data to initial student dataset');
    }
  };

  const handleClearAll = () => {
    if (window.confirm('Are you sure you want to clear all recorded expenses?')) {
      setExpenses([]);
      showToast('Cleared all expenses');
    }
  };

  const handleImportExpenses = (imported: Expense[]) => {
    setExpenses((prev) => [...imported, ...prev]);
    showToast(`Imported ${imported.length} new records`);
  };

  return (
    <div className="min-h-screen bg-slate-100 flex flex-col font-sans text-slate-800 antialiased selection:bg-indigo-500 selection:text-white">
      {/* Top Navigation */}
      <Navbar
        activeTab={activeTab}
        setActiveTab={setActiveTab}
        totalCount={expenses.length}
        onResetData={handleResetData}
        onClearAll={handleClearAll}
      />

      {/* Floating Toast Notification */}
      {toastMessage && (
        <div className="fixed bottom-6 right-6 z-50 bg-slate-900 text-white text-xs font-bold px-4 py-3 rounded-xl shadow-lg border border-slate-700 flex items-center space-x-2 animate-bounce">
          <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
          <span>{toastMessage}</span>
        </div>
      )}

      {/* Main Container */}
      <main className="flex-1 max-w-7xl w-full mx-auto px-4 sm:px-6 lg:px-8 py-6 sm:py-8">
        {activeTab === 'dashboard' && (
          <Dashboard
            expenses={expenses}
            budgets={budgets}
            setActiveTab={setActiveTab}
            onEditExpense={setEditingExpense}
          />
        )}

        {activeTab === 'logger' && (
          <div className="max-w-4xl mx-auto">
            <SmartLogger
              onAddExpense={handleAddExpense}
              onNavigateToLogs={() => setActiveTab('logs')}
            />
          </div>
        )}

        {activeTab === 'logs' && (
          <ExpenseTimeline
            expenses={expenses}
            onEditExpense={setEditingExpense}
            onDeleteExpense={handleDeleteExpense}
            onQuickAdd={() => setActiveTab('logger')}
          />
        )}

        {activeTab === 'heatmap' && (
          <ExpenseHeatmap expenses={expenses} />
        )}

        {(activeTab === 'budgets' || (activeTab as string) === 'budget') && (
          <BudgetManager
            expenses={expenses}
            budgets={budgets}
            onUpdateBudgets={handleUpdateBudgets}
          />
        )}

        {activeTab === 'analytics' && (
          <VisualAnalytics expenses={expenses} budgets={budgets} />
        )}

        {activeTab === 'reports' && (
          <ReportsView
            expenses={expenses}
            budgets={budgets}
            onImportExpenses={handleImportExpenses}
          />
        )}
      </main>

      {/* Modal for Editing Expense */}
      {editingExpense && (
        <EditExpenseModal
          expense={editingExpense}
          onSave={handleUpdateExpense}
          onClose={() => setEditingExpense(null)}
          onDelete={handleDeleteExpense}
        />
      )}

      {/* Institutional Footer */}
      <footer className="bg-white border-t border-slate-200 py-6 mt-12 text-xs text-slate-500">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 flex flex-col sm:flex-row items-center justify-between gap-3">
          <div className="flex items-center space-x-2">
            <span className="font-black text-slate-900 tracking-tight">SpendWise</span>
            <span className="text-slate-300">|</span>
            <span>Smart Student Expense Tracker with Visual Logs</span>
          </div>

          <div className="flex items-center space-x-4">
            <span>Tagline: "Track. Understand. Improve Your Spending."</span>
          </div>
        </div>
      </footer>
    </div>
  );
}
