# SpendWise — Smart Student Expense Tracker & Spending Analytics

A client-side web application that helps college students log, understand, and control their day-to-day spending — using natural-language expense entry, a visual heatmap calendar, a rule-based spending personality engine, statistical anomaly detection, and monthly budget management.

Built as an original project for the VITyarthi flipped-course evaluation.

## Overview

The hardest part of personal expense tracking is not analysis — it is data entry. A student buying a ₹40 bus ticket will not open an app and complete a five-field form, so logging is abandoned within days and the dataset never becomes complete enough to be useful.

SpendWise reduces logging to a single sentence typed the way a student would actually say it — `₹120 lunch at college canteen` — and infers the amount, description, category, date, and payment method automatically through a regex tokenisation and keyword-matching engine.

Once data is captured with low friction, the application converts that history into interpretable insight rather than raw tables: a colour-graded heatmap of daily spending velocity, a data-driven spending personality with a transparent rationale, statistically grounded anomaly alerts, and a budget engine that computes a safe daily allowance for the remaining days of the month.

**The application runs entirely in the browser.** There is no backend, no account, no API key, and no network request — all financial data stays in the student's own `localStorage`.

## Features

### 1. Smart Natural Language Expense Logger
- Parses freeform entries such as `₹120 lunch at college canteen`, `40 bus ticket`, `250 xerox and textbooks`, or `1800 hostel wifi bills` using regex amount extraction plus keyword tokenisation.
- Automatically classifies into 8 student-tailored categories: **Food & Dining 🍔, Transportation 🚌, Academic & Study 📚, Entertainment 🍿, Shopping 🛍️, Health & Wellness 💊, Bills & Utilities ⚡, Other / Misc 📦**.
- Returns a confidence score and the matched keywords, so the student can see *why* a category was chosen.
- Includes a structured manual-entry tab with validation (positive amount, date picker, payment method, notes).

### 2. Visual Expense Heatmap Calendar
- Colours each day by total spend across a 5-tier intensity scale: **None**, **Low** (≤ ₹150), **Med** (≤ ₹400), **High** (≤ ₹850), **Surge** (> ₹850).
- Surfaces peak spend day, most frugal day, active logging streak, and weekend-vs-weekday split.
- Interactive day inspector — click any calendar cell to view that day's full transaction breakdown.

### 3. Spending Personality Engine
Assigns a data-driven profile from category expenditure ratios:

| Profile | Signal |
|---|---|
| The Campus Foodie 🍔 | Canteen visits, cafe runs, and food delivery dominate |
| The Academic Striver 📚 | Heavy investment in textbooks, xerox, and lab kits |
| The Daily Commuter 🚌 | Metro tokens, bus routes, and auto fares lead |
| The Social Butterfly 🍿 | Cinema, gaming, and social outings take centre stage |
| The Disciplined Saver 💰 | Prudent control over non-essential expenses |
| The Balanced Manager ⚖️ | Healthy equilibrium across all categories |

Each profile ships with a tagline, a key metric, the dominant-category percentage that triggered it, and tailored student advice — no black-box scoring.

### 4. Rule-Based Spending Anomaly Detector
- Computes per-category baseline averages and flags transactions that deviate significantly.
- Each alert reports the category average, the absolute difference, and the exact ratio to average, graded across three severities: **moderate**, **high**, and **extreme**.
- Phrased analytically rather than judgementally — e.g. a ₹2,450 purchase measured against a ₹180 Academic & Study baseline.

### 5. Monthly Budget Management
- Per-category monthly limits with spent, remaining, and percentage-used tracking.
- Four colour-coded status states: **Safe**, **Moderate**, **Near Limit**, **Exceeded**.
- Calculates a recommended daily spend allowance for the remaining days of the month.
- Inline limit editing and one-click reset to student defaults.

### 6. Visual Analytics & Reports
- Interactive SVG donut chart for category distribution with slice highlighting.
- Daily spending velocity bar chart and payment-method breakdown (**UPI, Cash, Debit Card, Credit Card, Net Banking**).
- Smart insight feed — weekend spending spikes, daily burn rate, budget warnings, leading category.
- Searchable, filterable, sortable expense timeline with inline editing.
- Formal report generation, printable statements, and CSV export/import.

## Technologies / Tools Used

| Layer | Technology |
|---|---|
| Framework | React 19 + TypeScript 5.8 |
| Build tool | Vite 6 |
| Styling | Tailwind CSS 4 |
| Icons | lucide-react |
| Animation | motion |
| Charts | Hand-authored SVG — no charting dependency |
| Parsing | Custom regex + keyword-map classifier |
| Persistence | Browser `localStorage` |
| Version control | Git + GitHub |

## Project Structure

```
spendwise/
├── src/
│   ├── components/
│   │   ├── SmartLogger.tsx         # NL + manual entry tabs
│   │   ├── Dashboard.tsx           # Summary cards, personality, insights
│   │   ├── ExpenseHeatmap.tsx      # 5-tier calendar + day inspector
│   │   ├── BudgetManager.tsx       # Limits, status badges, daily allowance
│   │   ├── VisualAnalytics.tsx     # SVG donut, bar charts, payment split
│   │   ├── ExpenseTimeline.tsx     # Filter, search, sort, edit, delete
│   │   ├── ReportsView.tsx         # Report generation, print, CSV I/O
│   │   ├── EditExpenseModal.tsx    # Inline expense editing
│   │   └── Navbar.tsx              # Navigation
│   ├── services/
│   │   ├── expenseParser.ts        # Regex tokenisation + keyword classification
│   │   ├── analyticsEngine.ts      # Aggregations, personality, insights, budgets
│   │   ├── anomalyDetector.ts      # Baseline averages + severity grading
│   │   └── storage.ts              # localStorage persistence + CSV
│   ├── data/
│   │   ├── categories.ts           # 8 categories with keyword maps & theming
│   │   └── sampleData.ts           # Demo dataset for first run
│   ├── types.ts                    # Shared TypeScript interfaces
│   ├── App.tsx
│   └── main.tsx
├── docs/diagrams/                  # Architecture, UML & ER diagrams
├── index.html
├── vite.config.ts
├── tsconfig.json
├── statement.md
└── package.json
```

**Module count:** 9 components + 4 services + 2 data modules + shared types = **16 meaningful modules**, ~4,900 lines of TypeScript.

## Steps to Install & Run the Project

**Prerequisites:** Node.js 18 or later.

1. **Clone the repository**
   ```bash
   git clone https://github.com/<your-username>/spendwise.git
   cd spendwise
   ```

2. **Install dependencies**
   ```bash
   npm install
   ```

3. **Run the development server**
   ```bash
   npm run dev
   ```
   Open `http://localhost:3000` in your browser.

4. **Build for production**
   ```bash
   npm run build
   npm run preview
   ```

No API keys, environment variables, or backend services are required.

## Instructions for Testing

**Type checking**
```bash
npm run lint      # runs tsc --noEmit across the project
```

**Manual validation checklist**

| # | Test | Expected result |
|---|---|---|
| 1 | Enter `₹120 lunch at college canteen` | Amount 120, category **Food & Dining** |
| 2 | Enter `250 xerox and textbooks` | Amount 250, category **Academic & Study** |
| 3 | Enter `1800 hostel wifi bills` | Amount 1800, category **Bills & Utilities** |
| 4 | Enter `40 bus ticket` | Amount 40, category **Transportation** |
| 5 | Enter text with no recognisable amount | Parser returns `amount: null`; entry not saved |
| 6 | Submit manual form with a zero/negative amount | Validation error shown; record not saved |
| 7 | Log expenses totalling over ₹850 on one date | Calendar cell renders in the **Surge** tier |
| 8 | Click a populated calendar cell | Day inspector lists that day's transactions |
| 9 | Log a large expense in a low-baseline category | Anomaly alert with ratio and severity |
| 10 | Log food-dominant history, open the dashboard | Personality resolves to **The Campus Foodie** |
| 11 | Set a category limit below current spend | Badge switches to **Exceeded** |
| 12 | Filter timeline by category and date range | Only matching expenses shown |
| 13 | Export CSV, clear data, re-import the file | All records restored with categories intact |
| 14 | Refresh the browser | All previously logged data persists |

## Screenshots

*Add screenshots of the dashboard, smart logger, heatmap calendar, budget manager, visual analytics, and reports view here.*

## Author

- **Name:** Aryan Patil
- **Registration No.:** 25BAI10768
- **Course:** Programming in Java
- **University:** VIT Bhopal University
